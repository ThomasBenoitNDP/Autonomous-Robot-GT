#!/usr/bin/env python
import roslib; roslib.load_manifest('rover_driver_base')
import rospy
from geometry_msgs.msg import Twist
import numpy
from numpy.linalg import pinv
from math import atan2, hypot, pi, cos, sin, fmod

prefix=["FL","FR","CL","CR","RL","RR"]

class RoverMotors:
    def __init__(self):
        self.steering={}
        self.drive={}
        for k in prefix:
            self.steering[k]=0.0
            self.drive[k]=0.0
    def copy(self,value):
        for k in prefix:
            self.steering[k]=value.steering[k]
            self.drive[k]=value.drive[k]

class DriveConfiguration:
    def __init__(self,radius,x,y,z):
        self.x = x
        self.y = y
        self.z = z
        self.radius = radius
        
class RoverKinematics:
    def __init__(self):
        self.X = numpy.asmatrix(numpy.zeros((3,1)))
        self.motor_state = RoverMotors()
        self.first_run = True

    def twist_to_motors(self, twist, drive_cfg, skidsteer=False):
        motors = RoverMotors()
        if skidsteer:
            for k in drive_cfg.keys():
                # Insert here the steering and velocity of 
                # each wheel in skid-steer mode
                
                Vb = [ twist.linear.x      , twist.linear.y  ]
                Hb = [ -1.*twist.angular.z , twist.angular.z ]
                
                Bw_CL = [ drive_cfg["CL"].y      , drive_cfg["CL"].x  ]
                Vwx_CL = Vb[0] + Hb[0]*Bw_CL[0]
                Vwy_CL = Vb[1] + Hb[1]*Bw_CL[1]
                
                Bw_CR = [ drive_cfg["CR"].y      , drive_cfg["CR"].x  ]
                Vwx_CR = Vb[0] + Hb[0]*Bw_CR[0]
                Vwy_CR = Vb[1] + Hb[1]*Bw_CR[1]
                
                Bw_CL = atan2( Vwy_CL , Vwx_CL )
                Bw_CL = fmod( Bw_CL + pi/2., 2*pi) - pi/2.

                Bw_CR = atan2( Vwy_CR , Vwx_CR )
                Bw_CR = fmod( Bw_CR + pi/2., 2*pi) - pi/2.
                
                PHI_CL = hypot( Vwy_CL , Vwx_CL )
                PHI_CR = hypot( Vwy_CR , Vwx_CR )
                
                motors.steering["CL"] = 0
                motors.drive["CL"] = PHI_CL 
                motors.steering["CR"] = 0
                motors.drive["CR"] = PHI_CR
                motors.steering["FL"] = 0
                motors.drive["FL"] = PHI_CL 
                motors.steering["FR"] = 0
                motors.drive["FR"] = PHI_CR
                motors.steering["RL"] = 0
                motors.drive["RL"] = PHI_CL 
                motors.steering["RR"] = 0
                motors.drive["RR"] = PHI_CR


        else:
            for k in drive_cfg.keys():
                # Insert here the steering and velocity of 
                # each wheel in rolling-without-slipping mode

                # Parameters :
                # - Vb : lineare velocity 
                # - Hb : angular velocity (z)
                # - Bw : linear position

                Vb = [ twist.linear.x      , twist.linear.y  ]
                Hb = [ -1.*twist.angular.z , twist.angular.z ]
                Bw = [ drive_cfg[k].y      , drive_cfg[k].x  ]
                
                #First   : Compute Vw    : Vw = Vb + Hb.Bw

                Vwx = Vb[0] + Hb[0]*Bw[0]
                Vwy = Vb[1] + Hb[1]*Bw[1]

                # Then    : Compute BETAw : atan(Vwy , Vwx)^2
                # Note    : BETAw is between [-pi/2 ; pi/2 ]
                # => We obtain motors.steering (rad)

                Bw = atan2( Vwy , Vwx )
                Bw = fmod( Bw + pi/2., 2*pi) - pi/2.

                # Finally : Compute .PHIw : .PHIw = hypot( Vwy, Vwx)
                # => We obtain motors.drive (rad.s-1)

                PHI = hypot( Vwy , Vwx )

                # We set values

                motors.steering[k]      = Bw
                motors.drive[k]         = PHI * 5
                
        return motors

    def integrate_odometry(self, motor_state, drive_cfg):
        # The first time, we need to initialise the state
		if self.first_run:
			self.motor_state.copy(motor_state)
			self.first_run = False
			return self.X
        # Insert here your odometry code
			
#----Front Wheels        		
		W_FR_x = drive_cfg["FR"].x
		W_FR_y = drive_cfg["FR"].y
        
		W_FL_x = drive_cfg["FL"].x
		W_FL_y = drive_cfg["FL"].y
        
		if abs(motor_state.drive["FR"] - self.motor_state.drive["FR"]) > pi:
			s_FR = (motor_state.drive["FR"] +2*pi)*drive_cfg["FR"].radius - self.motor_state.drive["FR"]*drive_cfg["FR"].radius
		else:
			s_FR = motor_state.drive["FR"]*drive_cfg["FR"].radius - self.motor_state.drive["FR"]*drive_cfg["FR"].radius
		
		if abs(motor_state.drive["FL"] - self.motor_state.drive["FL"]) > pi:
			s_FL = (motor_state.drive["FL"] +2*pi)*drive_cfg["FL"].radius - self.motor_state.drive["FL"]*drive_cfg["FL"].radius
		else:
			s_FL = motor_state.drive["FL"]*drive_cfg["FL"].radius - self.motor_state.drive["FL"]*drive_cfg["FL"].radius
        
		beta_FR = (motor_state.steering["FR"] + self.motor_state.steering["FR"])/2.0 
		beta_FL = (motor_state.steering["FL"] + self.motor_state.steering["FL"])/2.0
     
                
 #----Center Wheels       
		W_CR_x = drive_cfg["CR"].x
		W_CR_y = drive_cfg["CR"].y
        
		W_CL_x = drive_cfg["CL"].x
		W_CL_y = drive_cfg["CL"].y
        
		if abs(motor_state.drive["CR"] - self.motor_state.drive["CR"]) > pi:
			s_CR = (motor_state.drive["CR"] +2*pi)*drive_cfg["CR"].radius - self.motor_state.drive["CR"]*drive_cfg["CR"].radius
		else:
			s_CR = motor_state.drive["CR"]*drive_cfg["CR"].radius - self.motor_state.drive["CR"]*drive_cfg["CR"].radius
			
		if abs(motor_state.drive["CL"] - self.motor_state.drive["CL"]) > pi:
			s_CL = (motor_state.drive["CL"] +2*pi)*drive_cfg["CL"].radius - self.motor_state.drive["CL"]*drive_cfg["CL"].radius
		else:
			s_CL = motor_state.drive["CL"]*drive_cfg["CL"].radius - self.motor_state.drive["CL"]*drive_cfg["CL"].radius
			
		beta_CR = (motor_state.steering["CR"] + self.motor_state.steering["CR"])/2.0
		beta_CL = (motor_state.steering["CL"] + self.motor_state.steering["CL"])/2.0

#----Rear Wheels
		W_RR_x = drive_cfg["RR"].x
		W_RR_y = drive_cfg["RR"].y
        
		W_RL_x = drive_cfg["RL"].x
		W_RL_y = drive_cfg["RL"].y
        
		if abs(motor_state.drive["RR"] - self.motor_state.drive["RR"]) > pi:
			s_RR = (motor_state.drive["RR"] +2*pi)*drive_cfg["RR"].radius - self.motor_state.drive["RR"]*drive_cfg["RR"].radius
		else:
			s_RR = motor_state.drive["RR"]*drive_cfg["RR"].radius - self.motor_state.drive["RR"]*drive_cfg["RR"].radius
			
		if abs(motor_state.drive["RL"] - self.motor_state.drive["RL"]) > pi:
			s_RL = (motor_state.drive["RL"] +2*pi)*drive_cfg["RL"].radius - self.motor_state.drive["RL"]*drive_cfg["RL"].radius
		else:
			s_RL = motor_state.drive["RL"]*drive_cfg["RL"].radius - self.motor_state.drive["RL"]*drive_cfg["RL"].radius
			
		beta_RR = (motor_state.steering["RR"] + self.motor_state.steering["RR"])/2.0
		beta_RL = (motor_state.steering["RL"] + self.motor_state.steering["RL"])/2.0
       
       
		A = numpy.array([[1,0,-W_FL_y],[0,1,W_FL_x],[1,0,-W_FR_y],[0,1,W_FR_x],[1,0,-W_CL_y],[0,1,W_CL_x],[1,0,-W_CR_y],[0,1,W_CR_x],[1,0,-W_RL_y],[0,1,W_RL_x],[1,0,-W_RR_y],[0,1,W_RR_x]])
		B = numpy.array([[s_FL*cos(beta_FL)],[s_FL*sin(beta_FL)],[s_FR*cos(beta_FR)],[s_FR*sin(beta_FR)],[s_CL*cos(beta_CL)],[s_CL*sin(beta_CL)],
                      [s_CR*cos(beta_CR)],[s_CR*sin(beta_CR)],[s_RL*cos(beta_RL)],[s_RL*sin(beta_RL)],[s_RR*cos(beta_RR)],[s_RR*sin(beta_RR)]])
		X = numpy.dot(pinv(A),B)

		self.X[2,0] += X[2,0]
		self.X[0,0] += X[0,0]*cos(self.X[2,0]) - X[1,0]*sin(self.X[2,0])
 		self.X[1,0] += X[0,0]*sin(self.X[2,0]) + X[1,0]*cos(self.X[2,0])
		
		self.motor_state.copy(motor_state)
        #print(self.X)
		return self.X



