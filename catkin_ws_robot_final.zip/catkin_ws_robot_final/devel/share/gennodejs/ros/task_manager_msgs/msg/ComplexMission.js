// Auto-generated. Do not edit!

// (in-package task_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ComplexMission {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.complex_mission = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('complex_mission')) {
        this.complex_mission = initObj.complex_mission
      }
      else {
        this.complex_mission = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ComplexMission
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [complex_mission]
    bufferOffset = _serializer.string(obj.complex_mission, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ComplexMission
    let len;
    let data = new ComplexMission(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [complex_mission]
    data.complex_mission = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    length += object.complex_mission.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'task_manager_msgs/ComplexMission';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9647881c2a5e72d377901e301913b48b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name
    string complex_mission
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ComplexMission(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.complex_mission !== undefined) {
      resolved.complex_mission = msg.complex_mission;
    }
    else {
      resolved.complex_mission = ''
    }

    return resolved;
    }
};

module.exports = ComplexMission;
