// Auto-generated. Do not edit!

// (in-package task_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TaskParameter = require('./TaskParameter.js');

//-----------------------------------------------------------

class TaskHistory {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tid = null;
      this.name = null;
      this.start_time = null;
      this.end_time = null;
      this.parameters = null;
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('tid')) {
        this.tid = initObj.tid
      }
      else {
        this.tid = 0;
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('start_time')) {
        this.start_time = initObj.start_time
      }
      else {
        this.start_time = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('end_time')) {
        this.end_time = initObj.end_time
      }
      else {
        this.end_time = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('parameters')) {
        this.parameters = initObj.parameters
      }
      else {
        this.parameters = [];
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskHistory
    // Serialize message field [tid]
    bufferOffset = _serializer.uint32(obj.tid, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [start_time]
    bufferOffset = _serializer.time(obj.start_time, buffer, bufferOffset);
    // Serialize message field [end_time]
    bufferOffset = _serializer.time(obj.end_time, buffer, bufferOffset);
    // Serialize message field [parameters]
    // Serialize the length for message field [parameters]
    bufferOffset = _serializer.uint32(obj.parameters.length, buffer, bufferOffset);
    obj.parameters.forEach((val) => {
      bufferOffset = TaskParameter.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskHistory
    let len;
    let data = new TaskHistory(null);
    // Deserialize message field [tid]
    data.tid = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [start_time]
    data.start_time = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [end_time]
    data.end_time = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [parameters]
    // Deserialize array length for message field [parameters]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.parameters = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.parameters[i] = TaskParameter.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    object.parameters.forEach((val) => {
      length += TaskParameter.getMessageSize(val);
    });
    return length + 29;
  }

  static datatype() {
    // Returns string type for a message object
    return 'task_manager_msgs/TaskHistory';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'db88715dff7ccff0b7e8111454321c74';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 TASK_NEWBORN = 0 
    uint8 TASK_CONFIGURED = 1
    uint8 TASK_INITIALISED = 2
    uint8 TASK_RUNNING = 3
    uint8 TASK_COMPLETED = 4
    uint8 TASK_TERMINATED = 5
    uint8 TASK_INTERRUPTED = 6
    uint8 TASK_FAILED = 7
    uint8 TASK_TIMEOUT = 8
    uint8 TASK_CONFIGURATION_FAILED = 9
    uint8 TASK_INITIALISATION_FAILED = 10
    
    uint32 tid
    string name
    time start_time
    time end_time
    TaskParameter[] parameters
    uint8 status
    
    ================================================================================
    MSG: task_manager_msgs/TaskParameter
    string name
    string description
    string type
    string min
    string max
    string dflt
    string value
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskHistory(null);
    if (msg.tid !== undefined) {
      resolved.tid = msg.tid;
    }
    else {
      resolved.tid = 0
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.start_time !== undefined) {
      resolved.start_time = msg.start_time;
    }
    else {
      resolved.start_time = {secs: 0, nsecs: 0}
    }

    if (msg.end_time !== undefined) {
      resolved.end_time = msg.end_time;
    }
    else {
      resolved.end_time = {secs: 0, nsecs: 0}
    }

    if (msg.parameters !== undefined) {
      resolved.parameters = new Array(msg.parameters.length);
      for (let i = 0; i < resolved.parameters.length; ++i) {
        resolved.parameters[i] = TaskParameter.Resolve(msg.parameters[i]);
      }
    }
    else {
      resolved.parameters = []
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
TaskHistory.Constants = {
  TASK_NEWBORN: 0,
  TASK_CONFIGURED: 1,
  TASK_INITIALISED: 2,
  TASK_RUNNING: 3,
  TASK_COMPLETED: 4,
  TASK_TERMINATED: 5,
  TASK_INTERRUPTED: 6,
  TASK_FAILED: 7,
  TASK_TIMEOUT: 8,
  TASK_CONFIGURATION_FAILED: 9,
  TASK_INITIALISATION_FAILED: 10,
}

module.exports = TaskHistory;
