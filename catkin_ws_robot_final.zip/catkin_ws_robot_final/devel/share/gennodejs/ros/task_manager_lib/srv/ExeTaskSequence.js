// Auto-generated. Do not edit!

// (in-package task_manager_lib.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let task_manager_msgs = _finder('task_manager_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class ExeTaskSequenceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sequence = null;
    }
    else {
      if (initObj.hasOwnProperty('sequence')) {
        this.sequence = initObj.sequence
      }
      else {
        this.sequence = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ExeTaskSequenceRequest
    // Serialize message field [sequence]
    // Serialize the length for message field [sequence]
    bufferOffset = _serializer.uint32(obj.sequence.length, buffer, bufferOffset);
    obj.sequence.forEach((val) => {
      bufferOffset = task_manager_msgs.msg.TaskDescriptionLight.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ExeTaskSequenceRequest
    let len;
    let data = new ExeTaskSequenceRequest(null);
    // Deserialize message field [sequence]
    // Deserialize array length for message field [sequence]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.sequence = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.sequence[i] = task_manager_msgs.msg.TaskDescriptionLight.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.sequence.forEach((val) => {
      length += task_manager_msgs.msg.TaskDescriptionLight.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/ExeTaskSequenceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fb850239ccd37600eb13f465f1e61f7b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    task_manager_msgs/TaskDescriptionLight[] sequence
    
    ================================================================================
    MSG: task_manager_msgs/TaskDescriptionLight
    string name
    string description
    bool periodic
    float32 timeout_s
    TaskParameter[] parameters 
    
    
    
    
    ================================================================================
    MSG: task_manager_msgs/TaskParameter
    string name
    string description
    string type
    string min
    string max
    string dflt
    string value
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ExeTaskSequenceRequest(null);
    if (msg.sequence !== undefined) {
      resolved.sequence = new Array(msg.sequence.length);
      for (let i = 0; i < resolved.sequence.length; ++i) {
        resolved.sequence[i] = task_manager_msgs.msg.TaskDescriptionLight.Resolve(msg.sequence[i]);
      }
    }
    else {
      resolved.sequence = []
    }

    return resolved;
    }
};

class ExeTaskSequenceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ExeTaskSequenceResponse
    // Serialize message field [id]
    bufferOffset = _serializer.int32(obj.id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ExeTaskSequenceResponse
    let len;
    let data = new ExeTaskSequenceResponse(null);
    // Deserialize message field [id]
    data.id = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/ExeTaskSequenceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c5e4a7d59c68f74eabcec876a00216aa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 id
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ExeTaskSequenceResponse(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: ExeTaskSequenceRequest,
  Response: ExeTaskSequenceResponse,
  md5sum() { return 'b8dd83e94b5f748423ea4fc5e54493d1'; },
  datatype() { return 'task_manager_lib/ExeTaskSequence'; }
};
