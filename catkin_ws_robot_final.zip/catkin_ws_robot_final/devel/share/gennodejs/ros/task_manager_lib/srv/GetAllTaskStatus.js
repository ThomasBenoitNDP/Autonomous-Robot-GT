// Auto-generated. Do not edit!

// (in-package task_manager_lib.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let task_manager_msgs = _finder('task_manager_msgs');

//-----------------------------------------------------------

class GetAllTaskStatusRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetAllTaskStatusRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetAllTaskStatusRequest
    let len;
    let data = new GetAllTaskStatusRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/GetAllTaskStatusRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetAllTaskStatusRequest(null);
    return resolved;
    }
};

class GetAllTaskStatusResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.running_tasks = null;
      this.zombie_tasks = null;
    }
    else {
      if (initObj.hasOwnProperty('running_tasks')) {
        this.running_tasks = initObj.running_tasks
      }
      else {
        this.running_tasks = [];
      }
      if (initObj.hasOwnProperty('zombie_tasks')) {
        this.zombie_tasks = initObj.zombie_tasks
      }
      else {
        this.zombie_tasks = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetAllTaskStatusResponse
    // Serialize message field [running_tasks]
    // Serialize the length for message field [running_tasks]
    bufferOffset = _serializer.uint32(obj.running_tasks.length, buffer, bufferOffset);
    obj.running_tasks.forEach((val) => {
      bufferOffset = task_manager_msgs.msg.TaskStatus.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [zombie_tasks]
    // Serialize the length for message field [zombie_tasks]
    bufferOffset = _serializer.uint32(obj.zombie_tasks.length, buffer, bufferOffset);
    obj.zombie_tasks.forEach((val) => {
      bufferOffset = task_manager_msgs.msg.TaskStatus.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetAllTaskStatusResponse
    let len;
    let data = new GetAllTaskStatusResponse(null);
    // Deserialize message field [running_tasks]
    // Deserialize array length for message field [running_tasks]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.running_tasks = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.running_tasks[i] = task_manager_msgs.msg.TaskStatus.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [zombie_tasks]
    // Deserialize array length for message field [zombie_tasks]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.zombie_tasks = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.zombie_tasks[i] = task_manager_msgs.msg.TaskStatus.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.running_tasks.forEach((val) => {
      length += task_manager_msgs.msg.TaskStatus.getMessageSize(val);
    });
    object.zombie_tasks.forEach((val) => {
      length += task_manager_msgs.msg.TaskStatus.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/GetAllTaskStatusResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4c3384f5c6e8242faeb6c444a9ccaae3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    task_manager_msgs/TaskStatus[] running_tasks
    task_manager_msgs/TaskStatus[] zombie_tasks
    
    
    ================================================================================
    MSG: task_manager_msgs/TaskStatus
    uint8 TASK_NEWBORN = 0 
    uint8 TASK_CONFIGURED = 1
    uint8 TASK_INITIALISED = 2
    uint8 TASK_RUNNING = 3
    uint8 TASK_COMPLETED = 4
    
    # To be used as a bit mask
    uint8 TASK_TERMINATED = 128
    
    uint8 TASK_INTERRUPTED = 6
    uint8 TASK_FAILED = 7
    uint8 TASK_TIMEOUT = 8
    uint8 TASK_CONFIGURATION_FAILED = 9
    uint8 TASK_INITIALISATION_FAILED = 10
    
    uint32 id
    string name
    uint8 status
    string status_string
    time status_time
    dynamic_reconfigure/Config plist
    
    ================================================================================
    MSG: dynamic_reconfigure/Config
    BoolParameter[] bools
    IntParameter[] ints
    StrParameter[] strs
    DoubleParameter[] doubles
    GroupState[] groups
    
    ================================================================================
    MSG: dynamic_reconfigure/BoolParameter
    string name
    bool value
    
    ================================================================================
    MSG: dynamic_reconfigure/IntParameter
    string name
    int32 value
    
    ================================================================================
    MSG: dynamic_reconfigure/StrParameter
    string name
    string value
    
    ================================================================================
    MSG: dynamic_reconfigure/DoubleParameter
    string name
    float64 value
    
    ================================================================================
    MSG: dynamic_reconfigure/GroupState
    string name
    bool state
    int32 id
    int32 parent
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetAllTaskStatusResponse(null);
    if (msg.running_tasks !== undefined) {
      resolved.running_tasks = new Array(msg.running_tasks.length);
      for (let i = 0; i < resolved.running_tasks.length; ++i) {
        resolved.running_tasks[i] = task_manager_msgs.msg.TaskStatus.Resolve(msg.running_tasks[i]);
      }
    }
    else {
      resolved.running_tasks = []
    }

    if (msg.zombie_tasks !== undefined) {
      resolved.zombie_tasks = new Array(msg.zombie_tasks.length);
      for (let i = 0; i < resolved.zombie_tasks.length; ++i) {
        resolved.zombie_tasks[i] = task_manager_msgs.msg.TaskStatus.Resolve(msg.zombie_tasks[i]);
      }
    }
    else {
      resolved.zombie_tasks = []
    }

    return resolved;
    }
};

module.exports = {
  Request: GetAllTaskStatusRequest,
  Response: GetAllTaskStatusResponse,
  md5sum() { return '4c3384f5c6e8242faeb6c444a9ccaae3'; },
  datatype() { return 'task_manager_lib/GetAllTaskStatus'; }
};
