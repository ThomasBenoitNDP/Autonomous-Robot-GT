// Auto-generated. Do not edit!

// (in-package task_manager_lib.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class ExeComplexMissionRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.mission_name = null;
    }
    else {
      if (initObj.hasOwnProperty('mission_name')) {
        this.mission_name = initObj.mission_name
      }
      else {
        this.mission_name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ExeComplexMissionRequest
    // Serialize message field [mission_name]
    bufferOffset = _serializer.string(obj.mission_name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ExeComplexMissionRequest
    let len;
    let data = new ExeComplexMissionRequest(null);
    // Deserialize message field [mission_name]
    data.mission_name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.mission_name.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/ExeComplexMissionRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '58d2a351cca0e183374ddcd0f9020808';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string mission_name
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ExeComplexMissionRequest(null);
    if (msg.mission_name !== undefined) {
      resolved.mission_name = msg.mission_name;
    }
    else {
      resolved.mission_name = ''
    }

    return resolved;
    }
};

class ExeComplexMissionResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pid = null;
    }
    else {
      if (initObj.hasOwnProperty('pid')) {
        this.pid = initObj.pid
      }
      else {
        this.pid = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ExeComplexMissionResponse
    // Serialize message field [pid]
    bufferOffset = _serializer.int32(obj.pid, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ExeComplexMissionResponse
    let len;
    let data = new ExeComplexMissionResponse(null);
    // Deserialize message field [pid]
    data.pid = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/ExeComplexMissionResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ea869443c246f5e50c4a1211c67c339d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 pid
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ExeComplexMissionResponse(null);
    if (msg.pid !== undefined) {
      resolved.pid = msg.pid;
    }
    else {
      resolved.pid = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: ExeComplexMissionRequest,
  Response: ExeComplexMissionResponse,
  md5sum() { return '848ee494e692fbadc2d74359a2e86ed0'; },
  datatype() { return 'task_manager_lib/ExeComplexMission'; }
};
