
"use strict";

let SaveComplexMission = require('./SaveComplexMission.js')
let GetAllTaskStatus = require('./GetAllTaskStatus.js')
let GetTaskListLight = require('./GetTaskListLight.js')
let StartTask = require('./StartTask.js')
let ListMissions = require('./ListMissions.js')
let StopComplexMission = require('./StopComplexMission.js')
let ExeComplexMission = require('./ExeComplexMission.js')
let ExeTaskSequence = require('./ExeTaskSequence.js')
let GetHistory = require('./GetHistory.js')
let StopTask = require('./StopTask.js')
let SaveBasicMission = require('./SaveBasicMission.js')
let GetTaskList = require('./GetTaskList.js')

module.exports = {
  SaveComplexMission: SaveComplexMission,
  GetAllTaskStatus: GetAllTaskStatus,
  GetTaskListLight: GetTaskListLight,
  StartTask: StartTask,
  ListMissions: ListMissions,
  StopComplexMission: StopComplexMission,
  ExeComplexMission: ExeComplexMission,
  ExeTaskSequence: ExeTaskSequence,
  GetHistory: GetHistory,
  StopTask: StopTask,
  SaveBasicMission: SaveBasicMission,
  GetTaskList: GetTaskList,
};
