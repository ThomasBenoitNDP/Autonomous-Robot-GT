
"use strict";

let RegionOfInterestArray = require('./RegionOfInterestArray.js');

module.exports = {
  RegionOfInterestArray: RegionOfInterestArray,
};
