#ifndef TASK_AUTO_DOCKING_H
#define TASK_AUTO_DOCKING_H

#include "task_manager_lib/TaskDefinition.h"
#include "floor_nav/SimTasksEnv.h"
#include "task_manager_action/TaskActionGeneric.h"
#include "floor_nav/TaskActionAutoDockingConfig.h"
#include <kobuki_msgs/AutoDockingAction.h>
#include <tf/transform_datatypes.h>

namespace floor_nav {
    class TaskActionAutoDocking : 
        public task_manager_action::TaskActionGeneric<kobuki_msgs::AutoDockingAction,TaskActionAutoDockingConfig, SimTasksEnv>
    {
        protected:
            typedef task_manager_action::TaskActionGeneric<kobuki_msgs::AutoDockingAction,
                    TaskActionAutoDockingConfig, SimTasksEnv> Parent;

            const std::string & getActionName() const {
                return Parent::cfg.action_name;
            }
            
            void buildActionGoal(typename Parent::Goal & goal) const {
            }
        public:
            TaskActionAutoDocking(task_manager_lib::TaskDefinitionPtr def, 
                    task_manager_lib::TaskEnvironmentPtr env) : Parent(def,env) {}
            virtual ~TaskActionAutoDocking() {};
    };

    class TaskFactoryActionAutoDocking : 
        public task_manager_lib::TaskDefinition<TaskActionAutoDockingConfig, SimTasksEnv, TaskActionAutoDocking>
    {
        protected:
            typedef task_manager_lib::TaskDefinition<TaskActionAutoDockingConfig, SimTasksEnv, TaskActionAutoDocking> Parent;
        public:
            TaskFactoryActionAutoDocking(task_manager_lib::TaskEnvironmentPtr env) : 
                Parent("ActionAutoDocking","Publish autodocking action",true,env) {}
            virtual ~TaskFactoryActionAutoDocking() {};
    };
};

#endif // TASK_AUTO_DOCKING_H
