#include <math.h>

#include "TaskGoToPoseRover.h"
#include "floor_nav/TaskGoToPoseRoverConfig.h"
using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

#define DEBUG_GOTO
#ifdef DEBUG_GOTO
#warning Debugging task GOTO
#endif



TaskIndicator TaskGoToPoseRover::initialise() 
{   
    ROS_INFO("Going to %.2f %.2f %.2f",cfg.goal_x,cfg.goal_y, cfg.goal_angle);
    if (cfg.relative) {
        const geometry_msgs::Pose2D & tpose = env->getPose2D();
        x_init = tpose.x;
        y_init = tpose.y;
	a_init = tpose.theta;
    } else {
        x_init = 0.0;
        y_init = 0.0;
	a_init = 0.0;
    }
    return TaskStatus::TASK_INITIALISED;
}


TaskIndicator TaskGoToPoseRover::iterate()
{
	double goal_angle;
	
	if (abs(cfg.goal_angle*M_PI/180.)> 2*M_PI) goal_angle = remainder(cfg.goal_angle*M_PI/180., 2*M_PI);	
	else goal_angle = cfg.goal_angle*M_PI/180.;
	
    const geometry_msgs::Pose2D & tpose = env->getPose2D();
    double r = hypot(y_init + cfg.goal_y-tpose.y,x_init + cfg.goal_x-tpose.x);
    
    // distance for x and y 
    double r1 =  x_init + cfg.goal_x-tpose.x ;
    double r2 =  y_init + cfg.goal_y-tpose.y ;
    
    double cond_final;  
      
    if (cfg.smart_mode == true){
		 cond_final = fabs( remainder(goal_angle + a_init - tpose.theta,2*M_PI) );
	}else {
		 cond_final = 0.0;
	}
     
    if (r < cfg.dist_threshold) {

		if(cond_final < cfg.angle_error){
			return TaskStatus::TASK_COMPLETED;
		}else{
			double diff_angle = remainder(goal_angle + a_init - tpose.theta,2*M_PI) ;
			
			if (diff_angle > M_PI) diff_angle = diff_angle -2*M_PI;
			else if (diff_angle < -1*M_PI) diff_angle = diff_angle + 2*M_PI; 	
	
			
            double w = cfg.k_v_f*(diff_angle);
            
#ifdef DEBUG_GOTO
            printf(" diff_angle = %.2f cond final = %.2f \n",  diff_angle, cond_final);
#endif
            env->publishVelocity(0,0,w);
            return TaskStatus::TASK_RUNNING;
		
		}
		
    }
     double alpha = remainder(atan2((y_init + cfg.goal_y-tpose.y),x_init + cfg.goal_x-tpose.x)-tpose.theta,2*M_PI);
      
	
#ifdef DEBUG_GOTO
    printf("c %.1f %.1f %.1f g %.1f %.1f r %.3f alpha %.1f\n",
            tpose.x, tpose.y, tpose.theta*180./M_PI,
            cfg.goal_x,cfg.goal_y,r,alpha*180./M_PI);
#endif
	
        double vel = cfg.k_v * r;
	
	// vel for x and y 
	double vel1 = cfg.k_v * r1;
	double vel2 = cfg.k_v * r2;
	
        double rot = std::max(std::min(cfg.k_alpha*alpha,cfg.max_angular_velocity),-cfg.max_angular_velocity);
        if (vel > cfg.max_velocity) vel = cfg.max_velocity;
#ifdef DEBUG_GOTO
        printf("Cmd v %.2f r %.2f\n",vel,rot);
#endif
        env->publishVelocity(vel1,vel2, 0);
   
       return TaskStatus::TASK_RUNNING;
}



/*********************/
TaskIndicator TaskGoToPoseRover::terminate()
{ 
#ifdef DEBUG_GOTO
    printf(" ON ST DANS LE TERMINATE  \n");
#endif
	env->publishVelocity(0,0,0);		
	return TaskStatus::TASK_TERMINATED;
}

DYNAMIC_TASK(TaskFactoryGoToPoseRover);

