#ifndef TASK_GOTOPOSE_ROVER_H
#define TASK_GOTOPOSE_ROVER_H

#include "task_manager_lib/TaskDefinition.h"
#include "floor_nav/SimTasksEnv.h"
#include "floor_nav/TaskGoToPoseRoverConfig.h"

using namespace task_manager_lib;

namespace floor_nav {
    class TaskGoToPoseRover : public TaskInstance<TaskGoToPoseRoverConfig,SimTasksEnv>
    {
        protected:
            double x_init,y_init, a_init;
        public:
            TaskGoToPoseRover(TaskDefinitionPtr def, TaskEnvironmentPtr env) : Parent(def,env) {}
            virtual ~TaskGoToPoseRover() {};

            virtual TaskIndicator initialise() ;

            virtual TaskIndicator iterate();

            virtual TaskIndicator terminate();
    };
    class TaskFactoryGoToPoseRover : public TaskDefinition<TaskGoToPoseRoverConfig, SimTasksEnv, TaskGoToPoseRover>
    {

        public:
            TaskFactoryGoToPoseRover(TaskEnvironmentPtr env) : 
                Parent("GoToPoseRover","Reach a desired destination",true,env) {}
            virtual ~TaskFactoryGoToPoseRover() {};
    };
};

#endif // TASK_GOTOPOSE_ROVER_H
