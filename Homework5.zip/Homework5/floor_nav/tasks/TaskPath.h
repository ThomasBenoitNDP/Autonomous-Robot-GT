#ifndef TASK_PATH_H
#define TASK_PATH_H

#include "task_manager_lib/TaskDefinition.h"
#include "floor_nav/SimTasksEnv.h"
#include "floor_nav/TaskPathConfig.h"

using namespace task_manager_lib;

namespace floor_nav {
    class TaskPath : public TaskInstance<TaskPathConfig,SimTasksEnv>
    {
        protected:
            double x_init,y_init;
        public:
            TaskPath(TaskDefinitionPtr def, TaskEnvironmentPtr env) : Parent(def,env) {}
            virtual ~TaskPath() {};

            virtual TaskIndicator iterate();

    };
    class TaskFactoryPath : public TaskDefinition<TaskPathConfig, SimTasksEnv, TaskPath>
    {

        public:
            TaskFactoryPath(TaskEnvironmentPtr env) : 
                Parent("Path","Publishes a Path",true,env) {}
            virtual ~TaskFactoryPath() {};
    };
};

#endif // TASK_PATH_H
