# AutonomousRobotics

mapGTL and mapGTLcorr are both based on gmapping.
What differs is how we drew the path :
- mapGTL is based on the robot odometry solely
- mapGTLcorr is based on the getpose2D method of the task server

Both paths have a slight shift in the orientation due to the odometry not being perfectly precise, even if mapGTLcorr wasn't supposed to.
Edit : mapGTLcorr still had a shift because we didn't change a topic in the gmapping launch on the turtlebot. It is now corrected but we still didn't redo the map. (To be done soon !)
