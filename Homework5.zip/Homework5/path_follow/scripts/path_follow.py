#!/usr/bin/env python
# Software License Agreement (BSD License)
# Hicham DERKAOUI for CS7630

import rospy
from nav_msgs.msg import Path, Odometry
from geometry_msgs.msg import Pose, PoseStamped
from math import sin, cos

#publisher
pub = rospy.Publisher('path_followed', Path, queue_size=10)

#Initialisation of the node
rospy.init_node('path_follow', anonymous=True)   

#Variable 
my_path = Path() 
my_path.header.frame_id = 'odom'  

#Rate at which the loop will repeat
rate = rospy.Rate(rospy.get_param('~hz', 10))

#Callback of the subscriber
def callback(msg):
	my_pose = PoseStamped()
	my_pose.pose.position.x = msg.position.x
	my_pose.pose.position.y = msg.position.y
	my_pose.pose.orientation.x = 0.0
	my_pose.pose.orientation.y = 0.0
	my_pose.pose.orientation.z = msg.orientation.z
	my_pose.pose.orientation.w = msg.orientation.w

	my_path.poses.append(my_pose) 
	
	   
#Subscriber for the vrep robot
sub = rospy.Subscriber('/path', Pose, callback)

#Loop
while not rospy.is_shutdown():
	pub.publish(my_path)
	rate.sleep()
