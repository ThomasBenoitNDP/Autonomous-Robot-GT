#include <math.h>
#include "TaskPath.h"
#include "floor_nav/TaskPathConfig.h"
using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

// #define DEBUG_PATH
#ifdef DEBUG_PATH
#warning Debugging task PATH
#endif


TaskIndicator TaskPath::iterate()
{
    const geometry_msgs::Pose2D & tpose = env->getPose2D();
    env->publishPose2D(tpose.x, tpose.y, tpose.theta);
    return TaskStatus::TASK_RUNNING;
}


DYNAMIC_TASK(TaskFactoryPath);
