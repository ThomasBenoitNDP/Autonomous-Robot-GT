#include <math.h>
#include "TaskActionAutoDocking.h"
#include "floor_nav/TaskActionAutoDockingConfig.h"

using namespace task_manager_msgs;
using namespace task_manager_lib;
using namespace floor_nav;

DYNAMIC_TASK(TaskFactoryActionAutoDocking);
