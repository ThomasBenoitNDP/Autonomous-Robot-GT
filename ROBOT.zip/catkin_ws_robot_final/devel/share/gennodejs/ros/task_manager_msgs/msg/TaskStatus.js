// Auto-generated. Do not edit!

// (in-package task_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let dynamic_reconfigure = _finder('dynamic_reconfigure');

//-----------------------------------------------------------

class TaskStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.name = null;
      this.status = null;
      this.status_string = null;
      this.status_time = null;
      this.plist = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
      if (initObj.hasOwnProperty('status_string')) {
        this.status_string = initObj.status_string
      }
      else {
        this.status_string = '';
      }
      if (initObj.hasOwnProperty('status_time')) {
        this.status_time = initObj.status_time
      }
      else {
        this.status_time = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('plist')) {
        this.plist = initObj.plist
      }
      else {
        this.plist = new dynamic_reconfigure.msg.Config();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskStatus
    // Serialize message field [id]
    bufferOffset = _serializer.uint32(obj.id, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    // Serialize message field [status_string]
    bufferOffset = _serializer.string(obj.status_string, buffer, bufferOffset);
    // Serialize message field [status_time]
    bufferOffset = _serializer.time(obj.status_time, buffer, bufferOffset);
    // Serialize message field [plist]
    bufferOffset = dynamic_reconfigure.msg.Config.serialize(obj.plist, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskStatus
    let len;
    let data = new TaskStatus(null);
    // Deserialize message field [id]
    data.id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [status_string]
    data.status_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [status_time]
    data.status_time = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [plist]
    data.plist = dynamic_reconfigure.msg.Config.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    length += object.status_string.length;
    length += dynamic_reconfigure.msg.Config.getMessageSize(object.plist);
    return length + 21;
  }

  static datatype() {
    // Returns string type for a message object
    return 'task_manager_msgs/TaskStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3554b5fe110c93fc0c13294dbb8822b9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 TASK_NEWBORN = 0 
    uint8 TASK_CONFIGURED = 1
    uint8 TASK_INITIALISED = 2
    uint8 TASK_RUNNING = 3
    uint8 TASK_COMPLETED = 4
    
    # To be used as a bit mask
    uint8 TASK_TERMINATED = 128
    
    uint8 TASK_INTERRUPTED = 6
    uint8 TASK_FAILED = 7
    uint8 TASK_TIMEOUT = 8
    uint8 TASK_CONFIGURATION_FAILED = 9
    uint8 TASK_INITIALISATION_FAILED = 10
    
    uint32 id
    string name
    uint8 status
    string status_string
    time status_time
    dynamic_reconfigure/Config plist
    
    ================================================================================
    MSG: dynamic_reconfigure/Config
    BoolParameter[] bools
    IntParameter[] ints
    StrParameter[] strs
    DoubleParameter[] doubles
    GroupState[] groups
    
    ================================================================================
    MSG: dynamic_reconfigure/BoolParameter
    string name
    bool value
    
    ================================================================================
    MSG: dynamic_reconfigure/IntParameter
    string name
    int32 value
    
    ================================================================================
    MSG: dynamic_reconfigure/StrParameter
    string name
    string value
    
    ================================================================================
    MSG: dynamic_reconfigure/DoubleParameter
    string name
    float64 value
    
    ================================================================================
    MSG: dynamic_reconfigure/GroupState
    string name
    bool state
    int32 id
    int32 parent
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskStatus(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    if (msg.status_string !== undefined) {
      resolved.status_string = msg.status_string;
    }
    else {
      resolved.status_string = ''
    }

    if (msg.status_time !== undefined) {
      resolved.status_time = msg.status_time;
    }
    else {
      resolved.status_time = {secs: 0, nsecs: 0}
    }

    if (msg.plist !== undefined) {
      resolved.plist = dynamic_reconfigure.msg.Config.Resolve(msg.plist)
    }
    else {
      resolved.plist = new dynamic_reconfigure.msg.Config()
    }

    return resolved;
    }
};

// Constants for message
TaskStatus.Constants = {
  TASK_NEWBORN: 0,
  TASK_CONFIGURED: 1,
  TASK_INITIALISED: 2,
  TASK_RUNNING: 3,
  TASK_COMPLETED: 4,
  TASK_TERMINATED: 128,
  TASK_INTERRUPTED: 6,
  TASK_FAILED: 7,
  TASK_TIMEOUT: 8,
  TASK_CONFIGURATION_FAILED: 9,
  TASK_INITIALISATION_FAILED: 10,
}

module.exports = TaskStatus;
