// Auto-generated. Do not edit!

// (in-package task_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TaskParameter = require('./TaskParameter.js');

//-----------------------------------------------------------

class TaskMission {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.task_name = null;
      this.task_parameters = null;
    }
    else {
      if (initObj.hasOwnProperty('task_name')) {
        this.task_name = initObj.task_name
      }
      else {
        this.task_name = '';
      }
      if (initObj.hasOwnProperty('task_parameters')) {
        this.task_parameters = initObj.task_parameters
      }
      else {
        this.task_parameters = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskMission
    // Serialize message field [task_name]
    bufferOffset = _serializer.string(obj.task_name, buffer, bufferOffset);
    // Serialize message field [task_parameters]
    // Serialize the length for message field [task_parameters]
    bufferOffset = _serializer.uint32(obj.task_parameters.length, buffer, bufferOffset);
    obj.task_parameters.forEach((val) => {
      bufferOffset = TaskParameter.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskMission
    let len;
    let data = new TaskMission(null);
    // Deserialize message field [task_name]
    data.task_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [task_parameters]
    // Deserialize array length for message field [task_parameters]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.task_parameters = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.task_parameters[i] = TaskParameter.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.task_name.length;
    object.task_parameters.forEach((val) => {
      length += TaskParameter.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'task_manager_msgs/TaskMission';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ee2c309c0266ea88e92ff9d954abea66';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string task_name
    TaskParameter[] task_parameters
    
    
    ================================================================================
    MSG: task_manager_msgs/TaskParameter
    string name
    string description
    string type
    string min
    string max
    string dflt
    string value
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskMission(null);
    if (msg.task_name !== undefined) {
      resolved.task_name = msg.task_name;
    }
    else {
      resolved.task_name = ''
    }

    if (msg.task_parameters !== undefined) {
      resolved.task_parameters = new Array(msg.task_parameters.length);
      for (let i = 0; i < resolved.task_parameters.length; ++i) {
        resolved.task_parameters[i] = TaskParameter.Resolve(msg.task_parameters[i]);
      }
    }
    else {
      resolved.task_parameters = []
    }

    return resolved;
    }
};

module.exports = TaskMission;
