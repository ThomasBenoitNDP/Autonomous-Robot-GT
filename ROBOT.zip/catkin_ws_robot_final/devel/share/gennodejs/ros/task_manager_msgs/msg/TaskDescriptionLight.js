// Auto-generated. Do not edit!

// (in-package task_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TaskParameter = require('./TaskParameter.js');

//-----------------------------------------------------------

class TaskDescriptionLight {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.description = null;
      this.periodic = null;
      this.timeout_s = null;
      this.parameters = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('description')) {
        this.description = initObj.description
      }
      else {
        this.description = '';
      }
      if (initObj.hasOwnProperty('periodic')) {
        this.periodic = initObj.periodic
      }
      else {
        this.periodic = false;
      }
      if (initObj.hasOwnProperty('timeout_s')) {
        this.timeout_s = initObj.timeout_s
      }
      else {
        this.timeout_s = 0.0;
      }
      if (initObj.hasOwnProperty('parameters')) {
        this.parameters = initObj.parameters
      }
      else {
        this.parameters = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskDescriptionLight
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [description]
    bufferOffset = _serializer.string(obj.description, buffer, bufferOffset);
    // Serialize message field [periodic]
    bufferOffset = _serializer.bool(obj.periodic, buffer, bufferOffset);
    // Serialize message field [timeout_s]
    bufferOffset = _serializer.float32(obj.timeout_s, buffer, bufferOffset);
    // Serialize message field [parameters]
    // Serialize the length for message field [parameters]
    bufferOffset = _serializer.uint32(obj.parameters.length, buffer, bufferOffset);
    obj.parameters.forEach((val) => {
      bufferOffset = TaskParameter.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskDescriptionLight
    let len;
    let data = new TaskDescriptionLight(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [description]
    data.description = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [periodic]
    data.periodic = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [timeout_s]
    data.timeout_s = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [parameters]
    // Deserialize array length for message field [parameters]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.parameters = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.parameters[i] = TaskParameter.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    length += object.description.length;
    object.parameters.forEach((val) => {
      length += TaskParameter.getMessageSize(val);
    });
    return length + 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'task_manager_msgs/TaskDescriptionLight';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ae2f4a06cc3f61cc243cea16daa0b221';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name
    string description
    bool periodic
    float32 timeout_s
    TaskParameter[] parameters 
    
    
    
    
    ================================================================================
    MSG: task_manager_msgs/TaskParameter
    string name
    string description
    string type
    string min
    string max
    string dflt
    string value
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskDescriptionLight(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.description !== undefined) {
      resolved.description = msg.description;
    }
    else {
      resolved.description = ''
    }

    if (msg.periodic !== undefined) {
      resolved.periodic = msg.periodic;
    }
    else {
      resolved.periodic = false
    }

    if (msg.timeout_s !== undefined) {
      resolved.timeout_s = msg.timeout_s;
    }
    else {
      resolved.timeout_s = 0.0
    }

    if (msg.parameters !== undefined) {
      resolved.parameters = new Array(msg.parameters.length);
      for (let i = 0; i < resolved.parameters.length; ++i) {
        resolved.parameters[i] = TaskParameter.Resolve(msg.parameters[i]);
      }
    }
    else {
      resolved.parameters = []
    }

    return resolved;
    }
};

module.exports = TaskDescriptionLight;
