// Auto-generated. Do not edit!

// (in-package task_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let dynamic_reconfigure = _finder('dynamic_reconfigure');

//-----------------------------------------------------------

class TaskDescription {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.description = null;
      this.periodic = null;
      this.config = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('description')) {
        this.description = initObj.description
      }
      else {
        this.description = '';
      }
      if (initObj.hasOwnProperty('periodic')) {
        this.periodic = initObj.periodic
      }
      else {
        this.periodic = false;
      }
      if (initObj.hasOwnProperty('config')) {
        this.config = initObj.config
      }
      else {
        this.config = new dynamic_reconfigure.msg.ConfigDescription();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskDescription
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [description]
    bufferOffset = _serializer.string(obj.description, buffer, bufferOffset);
    // Serialize message field [periodic]
    bufferOffset = _serializer.bool(obj.periodic, buffer, bufferOffset);
    // Serialize message field [config]
    bufferOffset = dynamic_reconfigure.msg.ConfigDescription.serialize(obj.config, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskDescription
    let len;
    let data = new TaskDescription(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [description]
    data.description = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [periodic]
    data.periodic = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [config]
    data.config = dynamic_reconfigure.msg.ConfigDescription.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    length += object.description.length;
    length += dynamic_reconfigure.msg.ConfigDescription.getMessageSize(object.config);
    return length + 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'task_manager_msgs/TaskDescription';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5caced38cd63847f02a113f31a826871';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name
    string description
    bool periodic
    # Reuse the parameter description for dynamic_reconfigure
    dynamic_reconfigure/ConfigDescription config
    
    ================================================================================
    MSG: dynamic_reconfigure/ConfigDescription
    Group[] groups
    Config max
    Config min
    Config dflt
    
    ================================================================================
    MSG: dynamic_reconfigure/Group
    string name
    string type
    ParamDescription[] parameters
    int32 parent 
    int32 id
    
    ================================================================================
    MSG: dynamic_reconfigure/ParamDescription
    string name
    string type
    uint32 level
    string description
    string edit_method
    
    ================================================================================
    MSG: dynamic_reconfigure/Config
    BoolParameter[] bools
    IntParameter[] ints
    StrParameter[] strs
    DoubleParameter[] doubles
    GroupState[] groups
    
    ================================================================================
    MSG: dynamic_reconfigure/BoolParameter
    string name
    bool value
    
    ================================================================================
    MSG: dynamic_reconfigure/IntParameter
    string name
    int32 value
    
    ================================================================================
    MSG: dynamic_reconfigure/StrParameter
    string name
    string value
    
    ================================================================================
    MSG: dynamic_reconfigure/DoubleParameter
    string name
    float64 value
    
    ================================================================================
    MSG: dynamic_reconfigure/GroupState
    string name
    bool state
    int32 id
    int32 parent
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskDescription(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.description !== undefined) {
      resolved.description = msg.description;
    }
    else {
      resolved.description = ''
    }

    if (msg.periodic !== undefined) {
      resolved.periodic = msg.periodic;
    }
    else {
      resolved.periodic = false
    }

    if (msg.config !== undefined) {
      resolved.config = dynamic_reconfigure.msg.ConfigDescription.Resolve(msg.config)
    }
    else {
      resolved.config = new dynamic_reconfigure.msg.ConfigDescription()
    }

    return resolved;
    }
};

module.exports = TaskDescription;
