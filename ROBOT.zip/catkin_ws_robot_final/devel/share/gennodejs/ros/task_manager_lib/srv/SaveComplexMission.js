// Auto-generated. Do not edit!

// (in-package task_manager_lib.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SaveComplexMissionRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.complex_mission = null;
    }
    else {
      if (initObj.hasOwnProperty('complex_mission')) {
        this.complex_mission = initObj.complex_mission
      }
      else {
        this.complex_mission = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaveComplexMissionRequest
    // Serialize message field [complex_mission]
    bufferOffset = _serializer.string(obj.complex_mission, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaveComplexMissionRequest
    let len;
    let data = new SaveComplexMissionRequest(null);
    // Deserialize message field [complex_mission]
    data.complex_mission = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.complex_mission.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/SaveComplexMissionRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'eaad400b956200fd4cd28b47c7d0b31b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string complex_mission
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaveComplexMissionRequest(null);
    if (msg.complex_mission !== undefined) {
      resolved.complex_mission = msg.complex_mission;
    }
    else {
      resolved.complex_mission = ''
    }

    return resolved;
    }
};

class SaveComplexMissionResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.filename = null;
    }
    else {
      if (initObj.hasOwnProperty('filename')) {
        this.filename = initObj.filename
      }
      else {
        this.filename = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaveComplexMissionResponse
    // Serialize message field [filename]
    bufferOffset = _serializer.string(obj.filename, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaveComplexMissionResponse
    let len;
    let data = new SaveComplexMissionResponse(null);
    // Deserialize message field [filename]
    data.filename = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.filename.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/SaveComplexMissionResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '030824f52a0628ead956fb9d67e66ae9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string filename
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaveComplexMissionResponse(null);
    if (msg.filename !== undefined) {
      resolved.filename = msg.filename;
    }
    else {
      resolved.filename = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SaveComplexMissionRequest,
  Response: SaveComplexMissionResponse,
  md5sum() { return '401f158a2116d288cef44bd9cc25d95c'; },
  datatype() { return 'task_manager_lib/SaveComplexMission'; }
};
