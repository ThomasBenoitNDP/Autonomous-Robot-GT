// Auto-generated. Do not edit!

// (in-package task_manager_lib.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let task_manager_msgs = _finder('task_manager_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SaveBasicMissionRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.basic_mission = null;
    }
    else {
      if (initObj.hasOwnProperty('basic_mission')) {
        this.basic_mission = initObj.basic_mission
      }
      else {
        this.basic_mission = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaveBasicMissionRequest
    // Serialize message field [basic_mission]
    // Serialize the length for message field [basic_mission]
    bufferOffset = _serializer.uint32(obj.basic_mission.length, buffer, bufferOffset);
    obj.basic_mission.forEach((val) => {
      bufferOffset = task_manager_msgs.msg.TaskDescriptionLight.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaveBasicMissionRequest
    let len;
    let data = new SaveBasicMissionRequest(null);
    // Deserialize message field [basic_mission]
    // Deserialize array length for message field [basic_mission]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.basic_mission = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.basic_mission[i] = task_manager_msgs.msg.TaskDescriptionLight.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.basic_mission.forEach((val) => {
      length += task_manager_msgs.msg.TaskDescriptionLight.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/SaveBasicMissionRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '655889804f6eaa243cbb7ffca6ab2136';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    task_manager_msgs/TaskDescriptionLight[] basic_mission
    
    ================================================================================
    MSG: task_manager_msgs/TaskDescriptionLight
    string name
    string description
    bool periodic
    float32 timeout_s
    TaskParameter[] parameters 
    
    
    
    
    ================================================================================
    MSG: task_manager_msgs/TaskParameter
    string name
    string description
    string type
    string min
    string max
    string dflt
    string value
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaveBasicMissionRequest(null);
    if (msg.basic_mission !== undefined) {
      resolved.basic_mission = new Array(msg.basic_mission.length);
      for (let i = 0; i < resolved.basic_mission.length; ++i) {
        resolved.basic_mission[i] = task_manager_msgs.msg.TaskDescriptionLight.Resolve(msg.basic_mission[i]);
      }
    }
    else {
      resolved.basic_mission = []
    }

    return resolved;
    }
};

class SaveBasicMissionResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.filename = null;
    }
    else {
      if (initObj.hasOwnProperty('filename')) {
        this.filename = initObj.filename
      }
      else {
        this.filename = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaveBasicMissionResponse
    // Serialize message field [filename]
    bufferOffset = _serializer.string(obj.filename, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaveBasicMissionResponse
    let len;
    let data = new SaveBasicMissionResponse(null);
    // Deserialize message field [filename]
    data.filename = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.filename.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/SaveBasicMissionResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '030824f52a0628ead956fb9d67e66ae9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string filename
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaveBasicMissionResponse(null);
    if (msg.filename !== undefined) {
      resolved.filename = msg.filename;
    }
    else {
      resolved.filename = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SaveBasicMissionRequest,
  Response: SaveBasicMissionResponse,
  md5sum() { return 'df017d4c21669f571bd046b4843485a1'; },
  datatype() { return 'task_manager_lib/SaveBasicMission'; }
};
