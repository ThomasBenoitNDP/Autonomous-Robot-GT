// Auto-generated. Do not edit!

// (in-package task_manager_lib.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let task_manager_msgs = _finder('task_manager_msgs');

//-----------------------------------------------------------

class ListMissionsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ListMissionsRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ListMissionsRequest
    let len;
    let data = new ListMissionsRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/ListMissionsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ListMissionsRequest(null);
    return resolved;
    }
};

class ListMissionsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.basic_missions = null;
      this.complex_missions = null;
    }
    else {
      if (initObj.hasOwnProperty('basic_missions')) {
        this.basic_missions = initObj.basic_missions
      }
      else {
        this.basic_missions = [];
      }
      if (initObj.hasOwnProperty('complex_missions')) {
        this.complex_missions = initObj.complex_missions
      }
      else {
        this.complex_missions = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ListMissionsResponse
    // Serialize message field [basic_missions]
    // Serialize the length for message field [basic_missions]
    bufferOffset = _serializer.uint32(obj.basic_missions.length, buffer, bufferOffset);
    obj.basic_missions.forEach((val) => {
      bufferOffset = task_manager_msgs.msg.BasicMission.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [complex_missions]
    // Serialize the length for message field [complex_missions]
    bufferOffset = _serializer.uint32(obj.complex_missions.length, buffer, bufferOffset);
    obj.complex_missions.forEach((val) => {
      bufferOffset = task_manager_msgs.msg.ComplexMission.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ListMissionsResponse
    let len;
    let data = new ListMissionsResponse(null);
    // Deserialize message field [basic_missions]
    // Deserialize array length for message field [basic_missions]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.basic_missions = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.basic_missions[i] = task_manager_msgs.msg.BasicMission.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [complex_missions]
    // Deserialize array length for message field [complex_missions]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.complex_missions = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.complex_missions[i] = task_manager_msgs.msg.ComplexMission.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.basic_missions.forEach((val) => {
      length += task_manager_msgs.msg.BasicMission.getMessageSize(val);
    });
    object.complex_missions.forEach((val) => {
      length += task_manager_msgs.msg.ComplexMission.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'task_manager_lib/ListMissionsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c9b1446f5e90029a6333f90885f64d75';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    task_manager_msgs/BasicMission[] basic_missions
    task_manager_msgs/ComplexMission[] complex_missions
    
    
    
    
    ================================================================================
    MSG: task_manager_msgs/BasicMission
    string name
    task_manager_msgs/TaskDescriptionLight[] basic_mission
    
    
    ================================================================================
    MSG: task_manager_msgs/TaskDescriptionLight
    string name
    string description
    bool periodic
    float32 timeout_s
    TaskParameter[] parameters 
    
    
    
    
    ================================================================================
    MSG: task_manager_msgs/TaskParameter
    string name
    string description
    string type
    string min
    string max
    string dflt
    string value
    
    
    
    ================================================================================
    MSG: task_manager_msgs/ComplexMission
    string name
    string complex_mission
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ListMissionsResponse(null);
    if (msg.basic_missions !== undefined) {
      resolved.basic_missions = new Array(msg.basic_missions.length);
      for (let i = 0; i < resolved.basic_missions.length; ++i) {
        resolved.basic_missions[i] = task_manager_msgs.msg.BasicMission.Resolve(msg.basic_missions[i]);
      }
    }
    else {
      resolved.basic_missions = []
    }

    if (msg.complex_missions !== undefined) {
      resolved.complex_missions = new Array(msg.complex_missions.length);
      for (let i = 0; i < resolved.complex_missions.length; ++i) {
        resolved.complex_missions[i] = task_manager_msgs.msg.ComplexMission.Resolve(msg.complex_missions[i]);
      }
    }
    else {
      resolved.complex_missions = []
    }

    return resolved;
    }
};

module.exports = {
  Request: ListMissionsRequest,
  Response: ListMissionsResponse,
  md5sum() { return 'c9b1446f5e90029a6333f90885f64d75'; },
  datatype() { return 'task_manager_lib/ListMissions'; }
};
