// Auto-generated. Do not edit!

// (in-package face_detect.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class RegionOfInterestArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ROIlist = null;
    }
    else {
      if (initObj.hasOwnProperty('ROIlist')) {
        this.ROIlist = initObj.ROIlist
      }
      else {
        this.ROIlist = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RegionOfInterestArray
    // Serialize message field [ROIlist]
    // Serialize the length for message field [ROIlist]
    bufferOffset = _serializer.uint32(obj.ROIlist.length, buffer, bufferOffset);
    obj.ROIlist.forEach((val) => {
      bufferOffset = sensor_msgs.msg.RegionOfInterest.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RegionOfInterestArray
    let len;
    let data = new RegionOfInterestArray(null);
    // Deserialize message field [ROIlist]
    // Deserialize array length for message field [ROIlist]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.ROIlist = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.ROIlist[i] = sensor_msgs.msg.RegionOfInterest.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 17 * object.ROIlist.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'face_detect/RegionOfInterestArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '53dd2e3b670c9dfe1f5c5be4fec79974';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    sensor_msgs/RegionOfInterest[] ROIlist
    
    ================================================================================
    MSG: sensor_msgs/RegionOfInterest
    # This message is used to specify a region of interest within an image.
    #
    # When used to specify the ROI setting of the camera when the image was
    # taken, the height and width fields should either match the height and
    # width fields for the associated image; or height = width = 0
    # indicates that the full resolution image was captured.
    
    uint32 x_offset  # Leftmost pixel of the ROI
                     # (0 if the ROI includes the left edge of the image)
    uint32 y_offset  # Topmost pixel of the ROI
                     # (0 if the ROI includes the top edge of the image)
    uint32 height    # Height of ROI
    uint32 width     # Width of ROI
    
    # True if a distinct rectified ROI should be calculated from the "raw"
    # ROI in this message. Typically this should be False if the full image
    # is captured (ROI not used), and True if a subwindow is captured (ROI
    # used).
    bool do_rectify
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RegionOfInterestArray(null);
    if (msg.ROIlist !== undefined) {
      resolved.ROIlist = new Array(msg.ROIlist.length);
      for (let i = 0; i < resolved.ROIlist.length; ++i) {
        resolved.ROIlist[i] = sensor_msgs.msg.RegionOfInterest.Resolve(msg.ROIlist[i]);
      }
    }
    else {
      resolved.ROIlist = []
    }

    return resolved;
    }
};

module.exports = RegionOfInterestArray;
