// Auto-generated. Do not edit!

// (in-package wpa_cli.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Network {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.bssid = null;
      this.ssid = null;
      this.frequency = null;
      this.level = null;
      this.flags = null;
    }
    else {
      if (initObj.hasOwnProperty('bssid')) {
        this.bssid = initObj.bssid
      }
      else {
        this.bssid = '';
      }
      if (initObj.hasOwnProperty('ssid')) {
        this.ssid = initObj.ssid
      }
      else {
        this.ssid = '';
      }
      if (initObj.hasOwnProperty('frequency')) {
        this.frequency = initObj.frequency
      }
      else {
        this.frequency = 0;
      }
      if (initObj.hasOwnProperty('level')) {
        this.level = initObj.level
      }
      else {
        this.level = 0;
      }
      if (initObj.hasOwnProperty('flags')) {
        this.flags = initObj.flags
      }
      else {
        this.flags = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Network
    // Serialize message field [bssid]
    bufferOffset = _serializer.string(obj.bssid, buffer, bufferOffset);
    // Serialize message field [ssid]
    bufferOffset = _serializer.string(obj.ssid, buffer, bufferOffset);
    // Serialize message field [frequency]
    bufferOffset = _serializer.int32(obj.frequency, buffer, bufferOffset);
    // Serialize message field [level]
    bufferOffset = _serializer.int32(obj.level, buffer, bufferOffset);
    // Serialize message field [flags]
    bufferOffset = _serializer.string(obj.flags, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Network
    let len;
    let data = new Network(null);
    // Deserialize message field [bssid]
    data.bssid = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [ssid]
    data.ssid = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [frequency]
    data.frequency = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [level]
    data.level = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [flags]
    data.flags = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.bssid.length;
    length += object.ssid.length;
    length += object.flags.length;
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'wpa_cli/Network';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '28179454d16234c00106c157dc67a22d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string bssid
    string ssid
    int32 frequency
    int32 level
    string flags
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Network(null);
    if (msg.bssid !== undefined) {
      resolved.bssid = msg.bssid;
    }
    else {
      resolved.bssid = ''
    }

    if (msg.ssid !== undefined) {
      resolved.ssid = msg.ssid;
    }
    else {
      resolved.ssid = ''
    }

    if (msg.frequency !== undefined) {
      resolved.frequency = msg.frequency;
    }
    else {
      resolved.frequency = 0
    }

    if (msg.level !== undefined) {
      resolved.level = msg.level;
    }
    else {
      resolved.level = 0
    }

    if (msg.flags !== undefined) {
      resolved.flags = msg.flags;
    }
    else {
      resolved.flags = ''
    }

    return resolved;
    }
};

module.exports = Network;
