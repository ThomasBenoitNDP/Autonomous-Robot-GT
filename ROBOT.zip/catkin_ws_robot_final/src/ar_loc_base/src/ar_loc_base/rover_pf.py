import roslib; roslib.load_manifest('ar_loc_base')
import rospy
from numpy import *
from numpy.linalg import pinv, inv
from math import pi, sin, cos
from geometry_msgs.msg import *
import tf
import bisect
import threading

from rover_kinematics import *

class RoverPF(RoverKinematics):
    def __init__(self, initial_pose, initial_uncertainty):
        RoverKinematics.__init__(self)
        self.initial_uncertainty = initial_uncertainty
        self.lock = threading.Lock()
        self.X = mat(vstack(initial_pose))
        # Initialisation of the particle cloud around the initial position
        self.N = 500
        self.particles = [self.X + self.drawNoise(initial_uncertainty) for i in range(0,self.N)]
        self.pa_pub = rospy.Publisher("~particles",PoseArray,queue_size=1)

    def getRotation(self, theta):
        R = mat(zeros((2,2)))
        R[0,0] = cos(theta); R[0,1] = -sin(theta)
        R[1,0] = sin(theta); R[1,1] = cos(theta)
        return R
    
    # Draw a vector uniformly around [0,0,0], scaled by norm
    def drawNoise(self, norm):
        if type(norm)==list: 
            return mat(vstack(norm)*(2*random.rand(3,1)-vstack([1,1,1])))
        else:
            return mat(multiply(norm,((2*random.rand(3,1)-vstack([1,1,1])))))


    def predict(self, motor_state, drive_cfg, encoder_precision):
        self.lock.acquire()
        # The first time, we need to initialise the state
        if self.first_run:
            self.motor_state.copy(motor_state)
            self.first_run = False
            self.lock.release()
            return 
        # Prepare odometry matrices (check rover_odo.py for usage)
        iW = self.prepare_inversion_matrix(drive_cfg)
        S = self.prepare_displacement_matrix(self.motor_state,motor_state,drive_cfg)
        self.motor_state.copy(motor_state)

        # Apply the particle filter prediction step here
        # TODO
	#Sampling
	x_t = []
	for m in self.particles :
	    S_noise = S + numpy.mat(numpy.random.normal(0, encoder_precision, S.shape)) 
	    theta = m[2,0]
	    Rtheta = mat([[cos(theta), -sin(theta), 0], 
		     [sin(theta),  cos(theta), 0],
                      [         0,           0, 1]]);
	    Deltaparticles = iW*S_noise
	    m = m + Rtheta*Deltaparticles
	    x = m[0,0] 
	    y = m[1,0]
	    theta = m[2,0]
	    x_t.append(numpy.mat([[x], [y], [theta]]))
	self.particles = x_t
	#print("sampling", self.particles.shape)
	
        self.lock.release()

    def update_ar(self, Z, L, Uncertainty):
        self.lock.acquire()
        print "Update: L="+str(L.T)
        # Implement particle filter update using landmarks here
        # Note: the function bisect.bisect_left could be useful to implement
        # the resampling process efficiently
        # TODO

	#Weights
	weight = []
	for m in self.particles :
	    L[0,0] = L[0,0]*cos(pi/2. - m[2,0]) + L[1,0]*(-1)*sin(pi/2. - m[2,0])
	    L[1,0] = L[0,0]*cos(pi/2. - m[2,0]) + L[1,0]*sin(pi/2. - m[2,0])
	    diff_vec = Z - L
	    score = numpy.linalg.norm(diff_vec)
	    weight_temp = exp((-1/2)*(score**2)/(Uncertainty**2))
	    weight.append(weight_temp)
	weight = weight/sum(weight)
 
	#Re-sampling
	self.particles_indices = [i for i in range(500)]
	self.particles_indices = numpy.random.choice(self.particles_indices, self.N, p=weight)

	self.particles_resampled = []
	for i in self.particles_indices :
	    self.particles_resampled.append(self.particles[i])
	
	self.particles = self.particles_resampled

        self.lock.release()

    def update_compass(self, angle, Uncertainty):
        self.lock.acquire()
        print "Update: C="+str(angle)
        # Implement particle filter update using landmarks here
        # Note: the function bisect.bisect_left could be useful to implement
        # the resampling process efficiently
        # TODO

	#Weights
	weight2 = []
	for m in self.particles :
	    diff_angle = angle - m[2,0]
	    score = numpy.linalg.norm(diff_angle)
	    weight2_temp = exp((-1/2)*(score**2)/(Uncertainty**2))
	    weight2.append(weight2_temp)
	weight2 = weight2/sum(weight2)

	#Re-sampling
	self.particles_indices = [i for i in range(500)]
	self.particles_indices = numpy.random.choice(self.particles_indices, self.N, p=weight2)

	self.particles_resampled2 = []
	for i in self.particles_indices :
	    self.particles_resampled2.append(self.particles[i])
	
	self.particles = self.particles_resampled2

        self.lock.release()

    def updateMean(self):
        X = mat(zeros((3,1)))
	for x in self.particles:
            X += x
        self.X = X / len(self.particles)
        
        return self.X

    def publish(self, pose_pub, target_frame, stamp):
        # Only compute the mean for plotting
        self.updateMean()
        pose = PoseStamped()
        pose.header.frame_id = target_frame
        pose.header.stamp = stamp
        pose.pose.position.x = self.X[0,0]
        pose.pose.position.y = self.X[1,0]
        pose.pose.position.z = 0.0
        Q = tf.transformations.quaternion_from_euler(0, 0, self.X[2,0])
        pose.pose.orientation.x = Q[0]
        pose.pose.orientation.y = Q[1]
        pose.pose.orientation.z = Q[2]
        pose.pose.orientation.w = Q[3]
        pose_pub.publish(pose)

        pa = PoseArray()
        pa.header = pose.header
        for p in self.particles:
            po = Pose()
            po.position.x = p[0,0]
            po.position.y = p[1,0]
            q = tf.transformations.quaternion_from_euler(0, 0, p[2,0])
            po.orientation = Quaternion(*q)
            pa.poses.append(po)
        self.pa_pub.publish(pa)

    def broadcast(self,br, target_frame, stamp):
        br.sendTransform((self.X[0,0], self.X[1,0], 0),
                     tf.transformations.quaternion_from_euler(0, 0, self.X[2,0]),
                     stamp, "/%s/ground"%self.name, target_frame)
        

