
#include <vector>
#include <string>
#include <map>
#include <list>


#include <ros/ros.h>
#include <tf/tf.h>
#include <tf/transform_listener.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>

#define FREE 0xFF
#define UNKNOWN 0x80
#define OCCUPIED 0x00
#define BORDER 0xDC
#define WIN_SIZE 800



/** Adding ***************************/

#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "highgui.h"
#include <stdlib.h>
#include <stdio.h>



/* State Machine values */
int STATE = 0;

bool POINT_TO_REACH_DETERMINED = false;
bool NO_POINT_TO_REACH = false;
bool GOAL_REACHED = false; 
bool TIMEOUT = false;
bool ROTATION_DONE = false;

bool STATE0 = true;
bool STATE1 = false;
bool STATE2 = false;
bool STATE3 = false;


/**********************************/



class OccupancyGridPlanner {
    protected:
        ros::NodeHandle nh_;
        ros::Subscriber og_sub_;
        ros::Subscriber target_sub_;
        ros::Publisher path_pub_;

	ros::Subscriber position_sub_;
	ros::Publisher target_pub_;
	ros::Publisher vel_pub_;

        tf::TransformListener listener_;

        cv::Rect roi_;
        cv::Mat_<uint8_t> og_, cropped_og_, border_, cropped_border_;
        cv::Mat_<cv::Vec3b> og_rgb_, og_rgb_marked_, border_rgb_, border_rgb_marked_;
        cv::Point og_center_, border_center_;
        nav_msgs::MapMetaData info_;
        std::string frame_id_;
        std::string base_link_;
        unsigned int neighbourhood_;
        bool ready;
        bool debug;
	double robot_radius_;


	/* EROSION */
	int erosion_elem = 2;

	// Erosion in relation to the robot dimension
	int erosion_size ;
	int const max_elem = 2;
	int const max_kernel_size = 21;

	/* Function Headers */
	void Erosion( int, void* );
	  
	/* Essential values */
	geometry_msgs::PoseStamped goal_to_reach;
	
	int H;
	int W;

        typedef std::multimap<float, cv::Point> Heap;

        // Callback for Occupancy Grids
        void og_callback(const nav_msgs::OccupancyGridConstPtr & msg) {
            info_ = msg->info;
            frame_id_ = msg->header.frame_id;
            // Create an image to store the value of the grid.
            og_ = cv::Mat_<uint8_t>(msg->info.height, msg->info.width,0xFF);
            og_center_ = cv::Point(-info_.origin.position.x/info_.resolution,
                    -info_.origin.position.y/info_.resolution);

            // Some variables to select the useful bounding box 
            unsigned int maxx=0, minx=msg->info.width, 
                         maxy=0, miny=msg->info.height;
            // Convert the representation into something easy to display.
            for (unsigned int j=0;j<msg->info.height;j++) {
                for (unsigned int i=0;i<msg->info.width;i++) {
                    int8_t v = msg->data[j*msg->info.width + i];
                    switch (v) {
                        case 0: 
                            og_(j,i) = FREE; 
                            break;
                        case 100: 
                            og_(j,i) = OCCUPIED; 
                            break;
                        case -1: 
                        default:
                            og_(j,i) = UNKNOWN; 
                            break;
                    }
                    // Update the bounding box of free or occupied cells.
                    if (og_(j,i) != UNKNOWN) {
                        minx = std::min(minx,i);
                        miny = std::min(miny,j);
                        maxx = std::max(maxx,i);
                        maxy = std::max(maxy,j);
                    }
                }
            }


 /** erosion of white parts **/
	    
	    int erosion_type;
	    int erosion_size = robot_radius_/info_.resolution ;
	    printf("robot_radius_ = %f \n info resolution = %f \n erosion_size = %f ",robot_radius_,info_.resolution,erosion_size);
	    if( erosion_elem == 0 ){ erosion_type = cv::MORPH_RECT; }
	    else if( erosion_elem == 1 ){ erosion_type = cv::MORPH_CROSS; }
	    else if( erosion_elem == 2) { erosion_type = cv::MORPH_ELLIPSE; }

	    cv::Mat element = cv::getStructuringElement( erosion_type, cv::Size( 2*erosion_size + 1, 2*erosion_size+1 ),cv::Point( erosion_size, erosion_size ) );
	    /// Apply the erosion operation
	    cv::erode(  og_, og_, element );

/**********************************/


		H = msg->info.height-1;
		W = msg->info.width-1 ;
		//establish border points
		border_ = og_.clone();
		border_center_ = cv::Point(-info_.origin.position.x/info_.resolution, -info_.origin.position.y/info_.resolution);
		
		for (unsigned int j=1;j<msg->info.height-1;j++) {
		    for (unsigned int i=1;i<msg->info.width-1;i++) {
			if (og_(j,i) == FREE) {
			    if (og_(j+1,i) == UNKNOWN || og_(j+1,i-1) == UNKNOWN || og_(j,i-1) == UNKNOWN || og_(j-1,i-1) == UNKNOWN || og_(j-1,i) == UNKNOWN || 
					    og_(j-1,i+1) == UNKNOWN || og_(j,i+1) == UNKNOWN || og_(j+1,i+1) == UNKNOWN ){
				border_(j,i) = BORDER;
			    }
			}
		    }
		}

	    	//determine the point to reach 
		if (STATE0){

		    tf::StampedTransform transform;
		    geometry_msgs::PoseStamped point_to_reach;
		    double minimum_distance = 850;
    
		    listener_.lookupTransform(frame_id_,base_link_, ros::Time(0), transform);
		    cv::Point current_position = cv::Point(transform.getOrigin().x() / info_.resolution, transform.getOrigin().y() / info_.resolution)
			+ og_center_;
		    
		    for (unsigned int j=1;j<H ;j++) {
			for (unsigned int i=1;i<W;i++) {
			    if (border_(j,i) == BORDER){
				//printf("i, c.x, j, c.y :%d,%d, %d, %d",i, current_position.x, j, current_position.y);
				double distance_btween_robot_border = hypot((i - current_position.x), (j - current_position.y));
				
				if (distance_btween_robot_border < minimum_distance){
				    printf("i, c.x, j, c.y :%d,%d, %d, %d",i, current_position.x, j, current_position.y);
				    minimum_distance = distance_btween_robot_border;
				    point_to_reach.header.stamp = ros::Time::now();
				    point_to_reach.header.frame_id = frame_id_;
				    point_to_reach.pose.position.x = i ;
				    point_to_reach.pose.position.y = j ;
				    point_to_reach.pose.position.z = 0 ;
				    point_to_reach.pose.orientation.x = 0 ;
				    point_to_reach.pose.orientation.y = 0 ;
				    point_to_reach.pose.orientation.z = 0 ;
				    point_to_reach.pose.orientation.w = 1 ;


				    printf(" point_to_reach has changed : (%f,%f), distance : %f \n",point_to_reach.pose.position.x,point_to_reach.pose.position.y, distance_btween_robot_border);
				}
			    }
			}
		    }
		    goal_to_reach = point_to_reach;
	    
		    POINT_TO_REACH_DETERMINED = true;

		    ROS_INFO("The point to reach is (%f,%f), distance : %f \n ",goal_to_reach.pose.position.x,goal_to_reach.pose.position.y, minimum_distance);
		    
		    target_pub_.publish(goal_to_reach);
		}



            if (!ready) {
                ready = true;
                ROS_INFO("Received occupancy grid, ready to plan");
            }
            // The lines below are only for display
            unsigned int w = maxx - minx;
            unsigned int h = maxy - miny;
            roi_ = cv::Rect(minx,miny,w,h);
            //cv::cvtColor(og_, og_rgb_, CV_GRAY2RGB);
            cv::cvtColor(border_, border_rgb_, CV_GRAY2RGB);
            // Compute a sub-image that covers only the useful part of the
            // grid.
	    cropped_border_ = cv::Mat_<uint8_t>(border_,roi_);
            //cropped_og_ = cv::Mat_<uint8_t>(og_,roi_);
            if ((w > WIN_SIZE) || (h > WIN_SIZE)) {
                // The occupancy grid is too large to display. We need to scale
                // it first.
                double ratio = w / ((double)h);
                cv::Size new_size;
                if (ratio >= 1) {
                    new_size = cv::Size(WIN_SIZE,WIN_SIZE/ratio);
                } else {
                    new_size = cv::Size(WIN_SIZE*ratio,WIN_SIZE);
                }
                //cv::Mat_<uint8_t> resized_og;
                //cv::resize(cropped_og_,resized_og,new_size);
                //cv::imshow( "OccGrid", resized_og );
                cv::Mat_<uint8_t> resized_border;
                cv::resize(cropped_border_,resized_border,new_size);
                cv::imshow( "OccGrid", resized_border );
            } else {
                // cv::imshow( "OccGrid", cropped_og_ );
                //cv::imshow( "OccGrid", og_rgb_ );
                cv::imshow( "OccGrid", border_rgb_ );

            }

	    if (STATE2){
		int tempo = 0;
		geometry_msgs::Twist twist_rot;
		twist_rot.linear.x = 0.0;
		twist_rot.angular.z = 0.25;
		while (tempo != 7*10e5 ){
		    vel_pub_.publish(twist_rot);
		    tempo++;
		}
		ROTATION_DONE = true;
	    }
	        

	    if (STATE3){
		geometry_msgs::Twist twist_end;
		twist_end.linear.x = 0.0;
		twist_end.angular.z = 0.0;
		vel_pub_.publish(twist_end);	
	    }

        }

        // Generic test if a point is within the occupancy grid
        bool isInGrid(const cv::Point & P) {
            if ((P.x < 0) || (P.x >= (signed)info_.width) 
                    || (P.y < 0) || (P.y >= (signed)info_.height)) {
                return false;
            }
            return true;
        }


        double euclidean_heuristic(const cv::Point & P, const cv::Point & target) {
	    return sqrt(pow(target.x - P.x, 2) + pow(target.y - P.y, 2));
        }


        // This is called when a new goal is posted by RViz. We don't use a
        // mutex here, because it can only be called in spinOnce.
        void target_callback(const geometry_msgs::PoseStampedConstPtr & msg) {
	    if (STATE1){
		tf::StampedTransform transform;
		geometry_msgs::PoseStamped pose;
		if (!ready) {
		    ROS_WARN("Ignoring target while the occupancy grid has not been received");
		    return;
		}
		ROS_INFO("Received planning request");
		border_rgb_marked_ = border_rgb_.clone();
		// Convert the destination point in the occupancy grid frame. 
		// The debug case is useful is the map is published without
		// gmapping running (for instance with map_server).
		if (debug) {
		    pose = *msg;
		} else {
		    // This converts target in the grid frame.
		    listener_.waitForTransform(frame_id_,msg->header.frame_id,msg->header.stamp,ros::Duration(1.0));
		    listener_.transformPose(frame_id_,*msg, pose);
		    // this gets the current pose in transform
		    listener_.lookupTransform(frame_id_,base_link_, ros::Time(0), transform);
		}
		// Now scale the target to the grid resolution and shift it to the
		// grid center.
		cv::Point target = cv::Point(pose.pose.position.x, pose.pose.position.y );
		ROS_INFO("Planning target: %.2f %.2f -> %d %d",
			    pose.pose.position.x, pose.pose.position.y, target.x, target.y);
		cv::circle(border_rgb_marked_,target, 10, cv::Scalar(0,0,255));
		cv::imshow( "OccGrid", border_rgb_marked_ );
		if (!isInGrid(target)) {
		    ROS_ERROR("Invalid target point (%.2f %.2f) -> (%d %d)",
			    pose.pose.position.x, pose.pose.position.y, target.x, target.y);
		    return;
		}
		// Only accept target which are FREE in the grid (HW, Step 5).
		if (og_(target) != FREE) {
		    ROS_ERROR("Invalid target point: occupancy = %d",og_(target));
		    return;
		}
    
		// Now get the current point in grid coordinates.
		cv::Point start;
		if (debug) {
		    start = og_center_;
		} else {
		    start = cv::Point(transform.getOrigin().x() / info_.resolution, transform.getOrigin().y() / info_.resolution)
			+ og_center_;
		}
		ROS_INFO("Planning origin %.2f %.2f -> %d %d",
			transform.getOrigin().x(), transform.getOrigin().y(), start.x, start.y);
		cv::circle(border_rgb_marked_,start, 10, cv::Scalar(0,255,0));
		cv::imshow( "OccGrid", border_rgb_marked_ );
		if (!isInGrid(start)) {
		    ROS_ERROR("Invalid starting point (%.2f %.2f) -> (%d %d)",
			    transform.getOrigin().x(), transform.getOrigin().y(), start.x, start.y);
		    return;
		}
		// If the starting point is not FREE there is a bug somewhere, but
		// better to check
		if (og_(start) != FREE) {
		    ROS_ERROR("Invalid start point: occupancy = %d",og_(start));
		    return;
		}
		ROS_INFO("Starting planning from (%d, %d) to (%d, %d)",start.x,start.y, target.x, target.y);
		// Here the Dijskstra algorithm starts 
		// The best distance to the goal computed so far. This is
		// initialised with Not-A-Number. 
		cv::Mat_<float> cell_value(og_.size(), NAN);
		// For each cell we need to store a pointer to the coordinates of
		// its best predecessor. 
		cv::Mat_<cv::Vec2s> predecessor(og_.size());
    
		// The neighbour of a given cell in relative coordinates. The order
		// is important. If we use 4-connexity, then we can use only the
		// first 4 values of the array. If we use 8-connexity we use the
		// full array.
		cv::Point neighbours[8] = {cv::Point(1,0), cv::Point(0,1), cv::Point(-1,0), cv::Point(0, -1),
		    cv::Point(1,1), cv::Point(-1,1), cv::Point(-1,-1), cv::Point(1,-1)};
		// Cost of displacement corresponding the neighbours. Diagonal
		// moves are 44% longer.
		float cost[8] = {1, 1, 1, 1, sqrt(2), sqrt(2), sqrt(2), sqrt(2)};
    
		// The core of Dijkstra's Algorithm, a sorted heap, where the first
		// element is always the closer to the start.
		Heap heap;
		heap.insert(Heap::value_type(euclidean_heuristic(start, target), start));
		while (!heap.empty()) {
		    // Select the cell at the top of the heap
		    Heap::iterator hit = heap.begin();
		    // the cell it contains is this_cell
		    cv::Point this_cell = hit->second;
		    if (this_cell == target) {
			break;
		    }
		    // and its score is this_cost
		    float this_cost = hit->first;
		    // We can remove it from the heap now.
		    heap.erase(hit);
		    // Now see where we can go from this_cell
		    for (unsigned int i=0;i<neighbourhood_;i++) {
			cv::Point dest = this_cell + neighbours[i];
			if (!isInGrid(dest)) {
			    // outside the grid
			    continue;
			}
			uint8_t og = og_(dest);
			if (og != FREE) {
			    // occupied or unknown
			    continue;
			}
			float cv = cell_value(dest);
			float new_cost = this_cost + cost[i];
			if (isnan(cv) || (new_cost < cv)) {
			    // found shortest path (or new path), updating the
			    // predecessor and the value of the cell
			    predecessor.at<cv::Vec2s>(dest) = cv::Vec2s(this_cell.x,this_cell.y);
			    cell_value(dest) = new_cost;
			    // And insert the selected cells in the map.
			    heap.insert(Heap::value_type(new_cost+euclidean_heuristic(dest, target),dest));
			}
		    }
		}
		if (isnan(cell_value(target))) {
		    // No path found
		    ROS_ERROR("No path found from (%d, %d) to (%d, %d)",start.x,start.y,target.x,target.y);
		    return;
		}
		ROS_INFO("Planning completed");
		// Now extract the path by starting from goal and going through the
		// predecessors until the starting point
		std::list<cv::Point> lpath;
		while (target != start) {
		    lpath.push_front(target);
		    cv::Vec2s p = predecessor(target);
		    target.x = p[0]; target.y = p[1];
		}
		lpath.push_front(start);
		// Finally create a ROS path message
		nav_msgs::Path path;
		path.header.stamp = ros::Time::now();
		path.header.frame_id = frame_id_;
		path.poses.resize(lpath.size());
		std::list<cv::Point>::const_iterator it = lpath.begin();
		unsigned int ipose = 0;
		while (it != lpath.end()) {
		    // time stamp is not updated because we're not creating a
		    // trajectory at this stage
		    path.poses[ipose].header = path.header;
		    cv::Point P = *it - og_center_;
		    path.poses[ipose].pose.position.x = (P.x) * info_.resolution;
		    path.poses[ipose].pose.position.y = (P.y) * info_.resolution;
		    path.poses[ipose].pose.orientation.x = 0;
		    path.poses[ipose].pose.orientation.y = 0;
		    path.poses[ipose].pose.orientation.z = 0;
		    path.poses[ipose].pose.orientation.w = 1;
		    ipose++;
		    it ++;
		}
		path_pub_.publish(path);
		ROS_INFO("Request completed");
        }
}



    public:
        OccupancyGridPlanner() : nh_("~") {
            int nbour = 4;
            ready = false;
            nh_.param("base_frame",base_link_,std::string("/body"));
            nh_.param("debug",debug,false);
            nh_.param("neighbourhood",nbour,nbour);
	    nh_.param("robot_radius_",robot_radius_,0.15);
            switch (nbour) {
                case 4: neighbourhood_ = nbour; break;
                case 8: neighbourhood_ = nbour; break;
                default: 
                    ROS_WARN("Invalid neighbourhood specification (%d instead of 4 or 8)",nbour);
                    neighbourhood_ = 8;
            }
            og_sub_ = nh_.subscribe("occ_grid",1,&OccupancyGridPlanner::og_callback,this);
            target_sub_ = nh_.subscribe("goal_to_pub",1,&OccupancyGridPlanner::target_callback,this);
            path_pub_ = nh_.advertise<nav_msgs::Path>("path",1,true);

	    target_pub_   = nh_.advertise<geometry_msgs::PoseStamped>("goal_to_pub",1,true);	    
	    vel_pub_   = nh_.advertise<geometry_msgs::Twist>("velocity_rot",1,true);
        }
};

int main(int argc, char * argv[]) {
    ros::init(argc,argv,"occgrid_planner");
    OccupancyGridPlanner ogp;
    cv::namedWindow( "OccGrid", CV_WINDOW_AUTOSIZE );
    double time_start = ros::Time::now().toSec();
    while (ros::ok()) {
	ros::spinOnce();
	TIMEOUT = false;
	if (ros::Time::now().toSec() - time_start > 5.0){
	    TIMEOUT = true;
	    time_start = ros::Time::now().toSec();
	}
        if (cv::waitKey( 50 )== 'q') {
            ros::shutdown();
        }
	    switch(STATE){
    		printf("%d", STATE);
		case 0:

		    STATE0 = true;
		    STATE1 = false;
		    STATE2 = false;
		    STATE3 = false;

		    ROS_INFO(" Current state :: State 0 :: Determine Point To Reach");
		    if (POINT_TO_REACH_DETERMINED){
			STATE = 1;
		    }
		    else if (NO_POINT_TO_REACH){
			STATE = 3;
		    }
		    else STATE = 0;
		    break;

	    	case 1:

		    STATE0 = false;
		    STATE1 = true;
		    STATE2 = false;
		    STATE3 = false;

		    ROS_INFO(" Current state :: State 1 :: Go to Point To Reach");
		    if (GOAL_REACHED) {
		    	STATE = 2;
		    }
		    else if (TIMEOUT) {
		    	STATE = 2;
		    }
		    else STATE = 1;
		    break;

	    	case 2:

		    STATE0 = false;
		    STATE1 = false;
		    STATE2 = true;
		    STATE3 = false;

		    ROS_INFO(" Current state :: State 2 :: Rotation on itself");
		    if (ROTATION_DONE) {
		    	STATE = 0;
		    }
		    else STATE = 2;
		    break;

	    	case 3:

		    STATE0 = false;
		    STATE1 = false;
		    STATE2 = false;
		    STATE3 = true;

		    ROS_INFO(" Current state :: State 3 :: Finished exploring");
		    STATE = 3;
		    break;
	    }
    }
}

