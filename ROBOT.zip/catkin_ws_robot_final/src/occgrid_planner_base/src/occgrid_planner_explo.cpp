
#include <vector>
#include <string>
#include <map>
#include <list>
#include "boost/tuple/tuple.hpp"
#include <ros/ros.h>
#include <tf/tf.h>
#include <tf/transform_listener.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <list>

#include <std_msgs/Float32.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>
#include <sensor_msgs/BatteryState.h>
#include "wpa_cli/Scan.h"
#include "wpa_cli/Network.h"

#define FREE 0xFF
#define UNKNOWN 0x80
#define OCCUPIED 0x00
#define BORDER 0xDC
#define WIN_SIZE 800

/**************************************/


#define WHITE       0xFE
#define LIGHT_GREY  0xC0
#define GREY        0x80
#define DARK_GREY   0x40
#define BLACK       0x00
#define IDC         0xBB
#define IDC2        0xDD

#define COL1 0xECFFA1 
#define COL2 0xE89C22
#define COL3 0xFF3238
#define COL4 0x5E19E8
#define COL5 0x38DEFF
#define COL6 0x333640
#define COL7 0xDF26EC

//using namespace std;
//using boost::tuple;
//typedef vector< tuple<int,int> > tuple_list;

/** Adding ***************************/

#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "highgui.h"
#include <stdlib.h>
#include <stdio.h>



/**********************************/


/* State Machine values */
int STATE = 0;
double TIME_START = 0;
bool POSE_ORIGIN = true;
cv::Point3i ORIGIN ;

bool POINT_TO_REACH_DETERMINED = false;
bool NO_POINT_TO_REACH = false;
bool GOAL_REACHED = false; 
bool TIMEOUT = false;
bool ROTATION_DONE = false;
bool START_UNKNOWN = false;
bool TARGET_UNKNOWN = false;
bool NO_PATH_FOUND = false;
bool BATTERY_LOW = false;
bool BATTERY_HIGH = false;
bool GO_TO_TRIGERRED = false;
bool BUTTON_PUSH = false;
bool DOCK = false;


bool STATE0 = true;
bool STATE1 = false;
bool STATE2 = false;
bool STATE3 = false;
bool STATE4 = false;
bool STATE5 = false;


class OccupancyGridPlanner {
    protected:
        ros::NodeHandle nh_;
        ros::Subscriber og_sub_;
        ros::Subscriber target_sub_;
        ros::Publisher path_pub_;

	/* add */
	ros::Subscriber position_sub_;
	ros::Publisher target_pub_;
	ros::Publisher vel_pub_;
	ros::Subscriber battery_sub_;
	ros::Subscriber button_sub_;
	ros::Subscriber wifi_sub_;
	/* */
        tf::TransformListener listener_;
        cv::Rect roi_;
        cv::Mat_<uint8_t> og_, cropped_og_, border_, cropped_border_, metal_, cropped_metal_;
	cv::Mat_<uint8_t> wifi_, cropped_wifi_;
        cv::Mat_<cv::Vec3b> og_rgb_, og_rgb_marked_, border_rgb_, border_rgb_marked_, metal_rgb_, metal_rgb_marked_, wifi_rgb_, wifi_rgb_marked_;
        cv::Point3i og_center_, border_center_, metal_center_, wifi_center_ ;
        nav_msgs::MapMetaData info_;
        std::string frame_id_;
        std::string base_link_;
        unsigned int neighbourhood_;
        bool ready;
        bool debug;
	double robot_radius_;

	std::vector<std::string> wifi_ssid_list_global;
	std::vector<std::string> wifi_bssid_list_global;
	std::vector<double> wifi_level_list_global;

	std::vector<std::string> unic_bssid_list;
	std::vector<uint8_t> color_list;


    	//float metal_info;
    	//bool FIRST_METAL = true;
    	bool FIRST_WIFI = true;
    	/* EROSION */
	int erosion_elem = 2;

	// Erosion in relation to the robot dimension
	int erosion_size ;
	int const max_elem = 2;
	int const max_kernel_size = 21;

	/* Function Headers */
	void Erosion( int, void* );
	  
	/* Essential values */
	//geometry_msgs::PoseStamped GOAL_COMPUTED;
    	cv::Point3i GOAL_COMPUTED;
	
	int H;
	int W;
	
        typedef std::multimap<float, cv::Point3i> Heap;

/**************************************************************************************/

        // Generic test if a point is within the occupancy grid
        bool isInGrid(const cv::Point3i & P) {
            if ((P.x < 0) || (P.x >= (signed)info_.width) 
                    || (P.y < 0) || (P.y >= (signed)info_.height)) {
                return false;
            }
            return true;
        }


        double euclidean_heuristic(const cv::Point3i & P, const cv::Point3i & target) {
	        return sqrt(pow(target.x - P.x, 2) + pow(target.y - P.y, 2));
        }

	template <class iterator_in, class iterator_out>
	     void rotate_pattern_90(iterator_in in_start, iterator_in in_end, iterator_out out_start) {
		 while (in_start != in_end) {
		    const cv::Point3i & Pin = *in_start;
		    *out_start = cv::Point3i(-Pin.y, Pin.x, Pin.z);
		    in_start++;
		    out_start++;
		}
	    }
    /*******************************************************************************/
    
	    // This is called when a new goal is posted by RViz. We don't use a
	    // mutex here, because it can only be called in spinO::Float32nce.
	    //void targeting (const geometry_msgs::PoseStampedConstPtr & msg) {
	    //void targeting (uint seq, time stamp, String frame_id,float posi_x,float posi_y, float posi_z, float quat_x, float quat_y, float quat_z, float quat_w   ) {
	    
    
	    //void target_callback (const geometry_msgs::PoseStampedConstPtr & msg) {
	void targeting (cv::Point3i target, cv::Point3i start, tf::StampedTransform transform ) {
	   // geometry_msgs::PoseStamped pose ;

	      //  ROS_INFO("We are planning");
            //tf::StampedTransform transform;

            if (!ready) {
                ROS_WARN("Ignoring target while the occupancy grid has not been received");
                return;
            }



            ROS_INFO("Received planning request");
            //og_rgb_marked_ = og_rgb_.clone();
            border_rgb_marked_ = border_rgb_.clone();
            // Convert the destination point in the occupancy grid frame.
            // The debug case is useful is the map is published without
            // gmapping running (for instance with map_server).


            /*if (debug) {
                pose = *msg;
            } else {
                // This converts target in the grid frame.
                listener_.waitForTransform(frame_id_,msg->header.frame_id,msg->header.stamp,ros::Duration(1.0));
                listener_.transformPose(frame_id_,*msg, pose);
                // this gets the current pose in transform
                listener_.lookupTransform(frame_id_,base_link_, ros::Time(0), transform);
            }*/
            // Now scale the target to the grid resolution and shift it to the
            // grid center.

            // target
            //cv::Point3i target = cv::Point3i(pose.pose.position.x , pose.pose.position.y , pose.pose.position.z);
            //ROS_INFO("target.z %d",(int) nearbyint(tf::getYaw(pose.pose.orientation)/M_PI_4) % 8);

            ROS_INFO("Planning target: %d %.d %d -> %d %d %d",
                    start.x, start.y, start.z, target.x, target.y, target.z);

            cv::circle(border_rgb_marked_,cv::Point(target.x, target.y), 10, cv::Scalar(0,0,255));
            cv::imshow( "OccGrid", border_rgb_marked_ );

            if (!isInGrid(target)) {
                ROS_ERROR("Invalid target point (%d %d) -> (%d %d)",
                    start.x, start.y, target.x, target.y);
                return;
            }
            // Only accept target which are FREE or BORDER in the grid (HW, Step 5).
            if ((og_(cv::Point(target.x, target.y)) != FREE)  && (og_(cv::Point(target.x, target.y)) != BORDER) ) {
                ROS_ERROR("Invalid target point: occupancy = %d",og_(cv::Point(target.x, target.y)));
                TARGET_UNKNOWN = true;
                return;
            }

            // Now get the current point in grid coordinate
                // Parameter
            //cv::Point3i start;


            /*if (debug) {
                start = og_center_;
            } else {
                start = cv::Point3i(transform.getOrigin().x() / info_.resolution, transform.getOrigin().y() / info_.resolution, ((int) (nearbyint(tf::getYaw(transform.getRotation())/M_PI_4)) + 8) % 8)
                + og_center_;
            }*/
            /*ROS_INFO("Planning origin %.2f %.2f %.2f -> %d %d %d",
                transform.getOrigin().x(), transform.getOrigin().y(), tf::getYaw(transform.getRotation()), start.x, start.y, start.z);*/
            cv::circle(border_rgb_marked_,cv::Point(start.x, start.y), 10, cv::Scalar(0,255,0));
            cv::imshow( "OccGrid", border_rgb_marked_ );
            if (!isInGrid(start)) {
                ROS_ERROR("Invalid starting point (%.2f %.2f) -> (%d %d)",
                    transform.getOrigin().x(), transform.getOrigin().y(), start.x, start.y);
                // ??? START_UNKNOWN = true;
                return;
            }
            // If the starting point is not FREE there is a bug somewhere, but
            // better to check
            if (og_(cv::Point(start.x, start.y)) != FREE) {
                ROS_ERROR("Invalid start point: occupancy = %d",og_(cv::Point(start.x, start.y)));
                START_UNKNOWN = true;
                return;
            }
            ROS_INFO("Starting planning from (%d, %d) to (%d, %d)",start.x,start.y, target.x, target.y);
            // Here the Dijskstra algorithm starts
            // The best distance to the goal computed so far. This is
            // initialised with Not-A-Number.
	    int dims[3] = {og_.size().width, og_.size().height, 8};
	    cv::Mat_<float> cell_value(3,dims, NAN);
	    // For each cell we need to store a pointer to the coordinates of
	    // its best predecessor.
	    cv::Mat_<cv::Vec3s> predecessor(3,dims);
    
	    // The neighbour of a given cell in relative coordinates. The order
	    // is important. If we use 4-connexity, then we can use only the
	    // first 4 values of the array. If we use 8-connexity we use the
	    // full array.
	    cv::Point3i neighbours_0[5] = {cv::Point3i(1,0,0),
					   cv::Point3i(1,1,1), cv::Point3i(1,-1,-1), cv::Point3i(0,0,1), cv::Point3i(0,0,-1)};
	    cv::Point3i neighbours_45[5] = {cv::Point3i(1,1,0),
					    cv::Point3i(0,1,1), cv::Point3i(1,0,-1), cv::Point3i(0,0,1), cv::Point3i(0,0,-1)};
    
	    std::vector< std::vector<cv::Point3i> > neighbours(8,std::vector<cv::Point3i>(5));
	    rotate_pattern_90(neighbours_0,neighbours_0+5,neighbours[2].begin());
	    rotate_pattern_90(neighbours_45,neighbours_45+5,neighbours[3].begin());
	    rotate_pattern_90(neighbours[2].begin(),neighbours[2].end(),neighbours[4].begin());
	    rotate_pattern_90(neighbours[3].begin(),neighbours[3].end(),neighbours[5].begin());
	    rotate_pattern_90(neighbours[4].begin(),neighbours[4].end(),neighbours[6].begin());
	    rotate_pattern_90(neighbours[5].begin(),neighbours[5].end(),neighbours[7].begin());
	    rotate_pattern_90(neighbours[6].begin(),neighbours[6].end(),neighbours[0].begin());
	    rotate_pattern_90(neighbours[7].begin(),neighbours[7].end(),neighbours[1].begin());
	    // Cost of displacement corresponding the neighbours. Diagonal
	    // moves are 44% longer.
	    float cost_0[5] = {1, 2*sqrt(2), 2*sqrt(2), 10, 10};
	    float cost_45[5] = {sqrt(2), 2, 2, 10, 10};
    
	    // The core of Dijkstra's Algorithm, a sorted heap, where the first
	    // element is always the closer to the start.
	    Heap heap;
	    heap.insert(Heap::value_type(euclidean_heuristic(start,target), start));
	    cell_value(start.x,start.y,start.z) = 0;
	    while (!heap.empty()) {
		// Select the cell at the top of the heap
		Heap::iterator hit = heap.begin();
		// the cell it contains is this_cell
		cv::Point3i this_cell = hit->second;
    
		assert(this_cell.z >= 0.0 );
		if (this_cell == target ) break;
    
		// and its score is this_cost
		float this_cost = cell_value(this_cell.x,this_cell.y,this_cell.z);
		// We can remove it from the heap now.
		heap.erase(hit);
		// Now see where we can go from this_cell
		for (unsigned int i=0;i<5;i++) {
		    cv::Point3i dest = this_cell + neighbours[this_cell.z][i];
		    dest.z = (dest.z + 8) % 8;
		    assert(this_cell.z >= 0.0 );
		    if (!isInGrid(dest)) {
			// outside the grid
			continue;
		    }
		    uint8_t og = og_(cv::Point(dest.x, dest.y));
		    if (og != FREE) {
			// occupied or unknown
			continue;
		    }
		    float cv = cell_value(dest.x,dest.y,dest.z);
		    float new_cost = this_cost + ((dest.z&1)?(cost_45[i]):(cost_0[i]));
		    if (isnan(cv) || (new_cost < cv)) {
			// found shortest path (or new path), updating the
			// predecessor and the value of the cell
			predecessor.at<cv::Vec3s>(dest.x,dest.y,dest.z) = cv::Vec3s(this_cell.x,this_cell.y,this_cell.z);
			cell_value(dest.x,dest.y,dest.z) = new_cost;
			// And insert the selected cells in the map.
			heap.insert(Heap::value_type(new_cost+euclidean_heuristic(dest,target),dest));
		    }
		}
	    }
	    if (isnan(cell_value(target.x,target.y,target.z))) {
		// No path found
		ROS_ERROR("No path found from (%d, %d, %d) to (%d, %d, %d)",
			  start.x,start.y,start.z,target.x,target.y,target.z);
		NO_PATH_FOUND = true;
		return;
	    }
	    ROS_INFO("Planning completed");
	    // Now extract the path by starting from goal and going through the
	    // predecessors until the starting point
	    std::list<cv::Point3i> lpath;
	    while (target != start) {
		lpath.push_front(target);
		cv::Vec3s p = predecessor(target.x,target.y,target.z);
		target.x = p[0]; target.y = p[1]; target.z = p[2];
		assert(lpath.size()<10000);
	    }
	    lpath.push_front(start);
	    // Finally create a ROS path message
	    nav_msgs::Path path;
	    path.header.stamp = ros::Time::now();
	    path.header.frame_id = frame_id_;
	    path.poses.resize(lpath.size());
	    std::list<cv::Point3i>::const_iterator it = lpath.begin();
	    unsigned int ipose = 0;
	    while (it != lpath.end()) {
		// time stamp is not updated because we're not creating a
		// trajectory at this stage
		path.poses[ipose].header = path.header;
		cv::Point3i P = *it - og_center_;
		path.poses[ipose].pose.position.x = (P.x) * info_.resolution;
		path.poses[ipose].pose.position.y = (P.y) * info_.resolution;
		tf::Quaternion Q = tf::createQuaternionFromRPY(0,0,P.z*M_PI/4);
		tf::quaternionTFToMsg(Q,path.poses[ipose].pose.orientation);
		path.poses[ipose].pose.orientation.x = 0;
		path.poses[ipose].pose.orientation.y = 0;
		path.poses[ipose].pose.orientation.z = 0;
		path.poses[ipose].pose.orientation.w = 1;
		ipose++;
		it ++;
	    }
	    path_pub_.publish(path);
	    ROS_INFO("Request completed");
	    
	    //REECRIRE
	    if (STATE0)  POINT_TO_REACH_DETERMINED = true;
	   
	    

	    // Timer is started
	    //TIME_START = ros::Time::now().toSec();
    	}

	

        // Callback for Occupancy Grids
        //void og_callback(const nav_msgs::OccupancyGridConstPtr & msg) {

	void wifi_callback(const wpa_cli::ScanConstPtr & msg_wifi){
	    /* Info on Wifi */
	    
	    std::vector <std::string> wifi_ssid_list;
	    std::vector <std::string> wifi_bssid_list;
	    std::vector <double> wifi_level_list;		
    
	    int size_wifi_list;
	    std::string wifi_frame_id_;
	    std::string wifi_ssid;
	    std::string wifi_bssid;
	    double wifi_level;
    
	    const std::vector <wpa_cli::Network> & wifi_list = msg_wifi -> networks;
	    size_wifi_list = wifi_list.size();
	    wifi_frame_id_ = msg_wifi -> header.frame_id;
    
	    for (unsigned int i=1;i<size_wifi_list;i++) { 
		wifi_ssid =  wifi_list[i].ssid;
		wifi_bssid =  wifi_list[i].bssid;
		wifi_level =  wifi_list[i].level;
    
		wifi_ssid_list.push_back(wifi_ssid);
		wifi_bssid_list.push_back(wifi_bssid);
		wifi_level_list.push_back(wifi_level);
    
		std::vector<std::string>::iterator it = std::find(unic_bssid_list.begin(), unic_bssid_list.end(), wifi_bssid);
		if (it != unic_bssid_list.end()){
		    unic_bssid_list.push_back(wifi_bssid);
		} 
	    }
    
	    wifi_ssid_list_global = wifi_ssid_list;
	    wifi_bssid_list_global = wifi_bssid_list;
	    wifi_level_list_global = wifi_level_list;
	    
	}
	/** Button callback **/
	void button_callback(const sensor_msgs::JoyConstPtr & msg ) {

	    const std::vector <int> & button_list = msg -> buttons;

	    if  (button_list[2] == 1) BUTTON_PUSH = true;
	}
	/** Battery callback **/
	void battery_callback(const sensor_msgs::BatteryStateConstPtr & msg ) {

	    sensor_msgs::BatteryState battery_info = *msg;
	    double battery = battery_info.percentage;

	    if (battery <= 20) BATTERY_LOW = true;
	    else if (battery > 80) BATTERY_HIGH = true;

	}

	void og_callback(const nav_msgs::OccupancyGridConstPtr & msg ) {
	
	    info_ = msg->info;
	    frame_id_ = msg->header.frame_id;
	    // Create an image to store the value of the grid.
	    og_ = cv::Mat_<uint8_t>(msg->info.height, msg->info.width,0xFF);
	    og_center_ = cv::Point3i(-info_.origin.position.x/info_.resolution,
		    -info_.origin.position.y/info_.resolution,0);
	
	    // Some variables to select the useful bounding box 
	    unsigned int maxx=0, minx=msg->info.width, 
			 maxy=0, miny=msg->info.height;
	    // Convert the representation into something easy to display.
	    for (unsigned int j=1;j<msg->info.height-1;j++) {
		for (unsigned int i=1;i<msg->info.width-1;i++) {
		    int8_t v = msg->data[j*msg->info.width + i];
		    switch (v) {
			case 0: 
			    og_(j,i) = FREE; 
			    break;
			case -1: 
			    og_(j,i) = UNKNOWN; 
			    break;
			case 100:
			default: 
			    og_(j,i) = OCCUPIED; 
			    break;
		    }
	
		    // Update the bounding box of free or occupied cells.
		    if (og_(j,i) != UNKNOWN) {
			minx = std::min(minx,i);
			miny = std::min(miny,j);
			maxx = std::max(maxx,i);
			maxy = std::max(maxy,j);
		    }
		}
	    }
		
	    // make border points occupied
	    for (unsigned int j=0;j<msg->info.height;j++) {
		    og_(j,0)= OCCUPIED;
	    }
	    for (unsigned int j=0;j<msg->info.height;j++) {
		    og_(j,msg->info.width-1)= OCCUPIED;
	    }
	    for (unsigned int i=0;i<msg->info.width;i++) {
		    og_(0,i)= OCCUPIED;
	    }
	    for (unsigned int i=0;i<msg->info.width;i++) {
		    og_(msg->info.height-1,i)= OCCUPIED;
	    }
	
	
	
	
	    /** erosion of white parts **/
	    
	    int erosion_type;
	    int erosion_size = robot_radius_/info_.resolution ;
	    printf("robot_radius_ = %f \n info resolution = %f \n erosion_size = %d ",robot_radius_,info_.resolution,erosion_size);
	    if( erosion_elem == 0 ){ erosion_type = cv::MORPH_RECT; }
	    else if( erosion_elem == 1 ){ erosion_type = cv::MORPH_CROSS; }
	    else if( erosion_elem == 2) { erosion_type = cv::MORPH_ELLIPSE; }
	
	    cv::Mat element = cv::getStructuringElement( erosion_type, cv::Size( 2*erosion_size + 1, 2*erosion_size+1 ),cv::Point( erosion_size, erosion_size ) );
	    /// Apply the erosion operation
	    //cv::erode(  og_, og_, element );
	
	    /**********************************/
		
	    if (!ready) {
		ready = true;
		ROS_INFO("Received occupancy grid, ready to plan");
	    }
	
	    H = msg->info.height-1;
	    W = msg->info.width-1 ;
	    //establish border points
	    border_ = og_.clone();
	    border_center_ = cv::Point3i(-info_.origin.position.x/info_.resolution, -info_.origin.position.y/info_.resolution,0);
	    
	    for (unsigned int j=1;j<msg->info.height-1;j++) {
		for (unsigned int i=1;i<msg->info.width-1;i++) {
		    if (og_(j,i) == FREE) {
			if (og_(j+1,i) == UNKNOWN || og_(j+1,i-1) == UNKNOWN || og_(j,i-1) == UNKNOWN || og_(j-1,i-1) == UNKNOWN || og_(j-1,i) == UNKNOWN || 
					og_(j-1,i+1) == UNKNOWN || og_(j,i+1) == UNKNOWN || og_(j+1,i+1) == UNKNOWN ){
			    border_(j,i) = BORDER;
			}
		    }
		}
	    }
	
	
	    //The lines below are only for display
	    unsigned int w = maxx - minx;
	    unsigned int h = maxy - miny;
	    roi_ = cv::Rect(minx,miny,w,h);
	    //cv::cvtColor(og_, og_rgb_, CV_GRAY2RGB);
	    cv::cvtColor(border_, border_rgb_, CV_GRAY2RGB);
	    //Compute a sub-image that covers only the useful part of the
	    //grid.
	    cropped_border_ = cv::Mat_<uint8_t>(border_,roi_);
	    //cropped_og_ = cv::Mat_<uint8_t>(og_,roi_);
	    if ((w > WIN_SIZE) || (h > WIN_SIZE)) {
		// The occupancy grid is too large to display. We need to scale
		// it first.
		double ratio = w / ((double)h);
		cv::Size new_size;
		if (ratio >= 1) {
		    new_size = cv::Size(WIN_SIZE,WIN_SIZE/ratio);
		} else {
		    new_size = cv::Size(WIN_SIZE*ratio,WIN_SIZE);
		}
		//cv::Mat_<uint8_t> resized_og;
		//cv::resize(cropped_og_,resized_og,new_size);
		//cv::imshow( "OccGrid", resized_og );
		cv::Mat_<uint8_t> resized_border;
		cv::resize(cropped_border_,resized_border,new_size);
		cv::imshow( "OccGrid", resized_border );
	    } else {
		//cv::imshow( "OccGrid", cropped_og_ );
		//cv::imshow( "OccGrid", og_rgb_ );
		cv::imshow( "OccGrid", border_rgb_ );
	    }
	
	
	
	    tf::StampedTransform transform;
	    listener_.lookupTransform(frame_id_,base_link_, ros::Time(0), transform);
	    cv::Point3i current_position = cv::Point3i(transform.getOrigin().x() / info_.resolution, transform.getOrigin().y() / info_.resolution, ((int) (nearbyint(tf::getYaw(transform.getRotation())/M_PI_4)) + 8) % 8)+ og_center_;
	    //determine the point to reach
	
	    if (POSE_ORIGIN){
		    ORIGIN = current_position;
		    POSE_ORIGIN = false;
	    }
	
	    if (STATE0){
	
		
	       // geometry_msgs::PoseStampedConstPtr point_to_reach;
		cv::Point3i point_to_reach;
		double minimum_distance = 850.0;
	
		int compteur = 0;
		
		for (unsigned int j=1;j<H ;j++) {
		    for (unsigned int i=1;i<W;i++) {
			if (border_(j,i) == BORDER){
			    /* +1 Border */
			    compteur ++;
			    //printf("i, c.x, j, c.y :%d,%d, %d, %d",i, current_position.x, j, current_position.y);
			    double hypo_x = double(i) - double(current_position.x) , hypo_y = double(j) - double(current_position.y);
	
			    hypo_x = ( hypo_x > 0)? hypo_x: -1.0*hypo_x;
			    hypo_y = ( hypo_y > 0)? hypo_y: -1.0*hypo_y;
			    double distance_btween_robot_border =hypot( hypo_x , hypo_y );
	
			    //ROS_INFO(" We are in Border Loop, and the distance is %f ",distance_btween_robot_border);
			    if (distance_btween_robot_border < minimum_distance && distance_btween_robot_border > 5.0){
				printf("i, c.x, j, c.y :%d,%d, %d, %d",i, current_position.x, j, current_position.y);
				minimum_distance = distance_btween_robot_border;
				/*
				point_to_reach->header.stamp = str(ros::Time::now());
				point_to_reach->header.frame_id = str(frame_id_);
				point_to_reach->pose.position.x = i ;
				point_to_reach->pose.position.y = j ;
				point_to_reach->pose.position.z = 0 ;
				point_to_reach->pose.orientation.x = 0 ;
				point_to_reach->pose.orientation.y = 0 ;
				point_to_reach->pose.orientation.z = 0 ;
				point_to_reach->pose.orientation.w = 1 ;*/
				point_to_reach.x = i;
				point_to_reach.y = j;
				point_to_reach.z = 0;
	
	
				//printf(" point_to_reach has changed : (%f,%f), distance : %f \n",point_to_reach.pose.position.x,point_to_reach.pose.position.y, distance_btween_robot_border);
				//printf(" point_to_reach has changed : (%d,%d), distance : %f \n",point_to_reach.x,point_to_reach.y, distance_btween_robot_border);
			    }
			}
		    }
		}
		GOAL_COMPUTED = point_to_reach;
	
	
	
		//printf(" point_to_reach has changed : (%f,%f), distance : %f \n",point_to_reach.pose.position.x,point_to_reach.pose.position.y, distance_btween_robot_border);
		//ROS_INFO(" point_to_reach has changed : (%f,%f), distance : %f ",point_to_reach.x,point_to_reach.y, minimum_distance);
		ROS_INFO(" point_to_reach has changed : (%d,%d), distance : %f ",point_to_reach.x,point_to_reach.y, minimum_distance);
	
		if(compteur > 6){
		    targeting (GOAL_COMPUTED, current_position , transform);
		    //POINT_TO_REACH_DETERMINED = true;
		}else  NO_POINT_TO_REACH = true;
	
	
		ROS_INFO("The end of the state 0 ");
	    }
	
	    else if (STATE1){
	
		double seuille = 0.20/info_.resolution;
		double error = hypot(GOAL_COMPUTED.x - current_position.x,GOAL_COMPUTED.y - current_position.y);
		ROS_INFO("error noticed : %f ",error);
	
		if ( error <= seuille ){
		    ROS_INFO("We arrived in the goal point , error noticed : %f ",error);
		    GOAL_REACHED = true;
		}
	
		
	    }
	    else if (STATE2){
		int tempo = 0;
		geometry_msgs::Twist twist_rot;
		twist_rot.linear.x = 0.0;
		twist_rot.angular.z = 1.0;
		while (tempo != 4*10e4 ){
		    vel_pub_.publish(twist_rot);
		    tempo++;
		}
		ROTATION_DONE = true;
	    }
	    
	    
	
	    else  if (STATE3){
		geometry_msgs::Twist twist_end;
		twist_end.linear.x = 0.0;
		twist_end.angular.z = 0.0;
		vel_pub_.publish(twist_end);
	
	    
	    } else if (STATE4){
		    // got + autodocking
		geometry_msgs::Twist twist_dck;
		twist_dck.linear.x = 0.0;
		twist_dck.angular.z = 0.0;

		
		targeting(ORIGIN, current_position , transform);
		
		double seuille2 = 0.40/info_.resolution;
		double error2 = hypot(ORIGIN.x - current_position.x,ORIGIN.y - current_position.y);
		
		if ( error2 <= seuille2 ){
			vel_pub_.publish(twist_dck);
		    GO_TO_TRIGERRED = true;
		    DOCK = true;
		}
	
		
	    } else if (STATE5){
		if (DOCK){
		    system("rosrun floor_nav autodock.py");		    
		    DOCK = false;
		}
	    }
	
	    /** WIFI *********************************/
	
	
	    //wifi_ssid_list_global;
	    //wifi_bssid_list_global;
	    //wifi_level_list_global;
	
	    if (FIRST_WIFI){
		FIRST_WIFI = false;
		wifi_ = cv::Mat_<uint8_t>(msg->info.height, msg->info.width,0xFF);
		wifi_center_ = cv::Point3i(-info_.origin.position.x/info_.resolution,
					    -info_.origin.position.y/info_.resolution,0);
	    }
	    
	    double max = *max_element(wifi_level_list_global.begin(), wifi_level_list_global.end());
	    //int max = int(max_d);
	
	    std::vector<double>::iterator it = std::find(wifi_level_list_global.begin(), wifi_level_list_global.end(), max);
	    int index = std::distance(wifi_level_list_global.begin(), it);
	    
	    int precision = 1/info_.resolution;
	    
	    //std::vector<uint8_t> color_list;
	    color_list.push_back(WHITE);
	    color_list.push_back(LIGHT_GREY);
	    color_list.push_back(GREY);
	    color_list.push_back(DARK_GREY);
	    color_list.push_back(BLACK);
	    color_list.push_back(IDC);
	    color_list.push_back(IDC2);
	
	    for (unsigned int i = current_position.x - precision; i < current_position.x + precision; i++) {
		for (unsigned int j = current_position.y - precision; j < current_position.y + precision; j++) {
		    std::string bssid_to_choose = wifi_bssid_list_global[index];
		    std::vector<std::string>::iterator it = std::find(unic_bssid_list.begin(), unic_bssid_list.end(), bssid_to_choose);
		    int index_color = std::distance(unic_bssid_list.begin(), it);
		    wifi_(j, i) = color_list[index_color];
	
		}
	    }
	    //cv::cvtColor(og_, og_rgb_, CV_GRAY2RGB); BGR
	    cv::cvtColor(wifi_, wifi_rgb_, CV_GRAY2RGB);
	    for (unsigned int j = 1; j < H-1; j++) {
		for (unsigned int i = 1; i < W-1; i++) {
		    if (wifi_(j, i) == WHITE){// VERT PALE
			wifi_rgb_(j,i)[0] = 117;
			wifi_rgb_(j,i)[1] = 204;
			wifi_rgb_(j,i)[2] = 185;
		    }		
		    else if (wifi_(j, i) == LIGHT_GREY){//BLEU TURQUOISE
			wifi_rgb_(j,i)[0] = 153;
			wifi_rgb_(j,i)[1] = 143;
			wifi_rgb_(j,i)[2] = 45;
		    }
		    else if (wifi_(j, i) == GREY){//BLEU VERT TRES CLAIR
			wifi_rgb_(j,i)[0] = 219;
			wifi_rgb_(j,i)[1] = 255;
			wifi_rgb_(j,i)[2] = 177;
		    }
		    else if (wifi_(j, i) == DARK_GREY){//SAUMON
			wifi_rgb_(j,i)[0] = 116;
			wifi_rgb_(j,i)[1] = 156;
			wifi_rgb_(j,i)[2] = 255;
		    }
		    else if (wifi_(j, i) == BLACK){//ROSE MAQUILLAGE
			wifi_rgb_(j,i)[0] = 167;
			wifi_rgb_(j,i)[1] = 121;
			wifi_rgb_(j,i)[2] = 204;
		    }
		    else if (wifi_(j, i) == IDC){//DORE BRONZE
			wifi_rgb_(j,i)[0] = 58;
			wifi_rgb_(j,i)[1] = 167;
			wifi_rgb_(j,i)[2] = 204;
		    }
		    else if (wifi_(j, i) == IDC2){//VIOLET
			wifi_rgb_(j,i)[0] = 255;
			wifi_rgb_(j,i)[1] = 55;
			wifi_rgb_(j,i)[2] = 104;
		    }
		}
	    }
	    // Compute a sub-image that covers only the useful part of the
	    // grid.
	    cropped_wifi_ = cv::Mat_<uint8_t>(wifi_,roi_);
	    //cropped_og_ = cv::Mat_<uint8_t>(og_,roi_);
	    if ((w > WIN_SIZE) || (h > WIN_SIZE)) {
		// The occupancy grid is too large to display. We need to scale
		// it first.
		double ratio = w / ((double)h);
		cv::Size new_size;
		if (ratio >= 1) {
		    new_size = cv::Size(WIN_SIZE,WIN_SIZE/ratio);
		} else {
		    new_size = cv::Size(WIN_SIZE*ratio,WIN_SIZE);
		}
		//cv::Mat_<uint8_t> resized_og;
		//cv::resize(cropped_og_,resized_og,new_size);
		//cv::imshow( "OccGrid", resized_og );
		cv::Mat_<uint8_t> resized_wifi;
		cv::resize(cropped_wifi_,resized_wifi,new_size);
		cv::imshow( "wifi ", resized_wifi );
	    } else {
		// cv::imshow( "OccGrid", cropped_og_ );
		//cv::imshow( "OccGrid", og_rgb_ );
		cv::imshow( "wifi ", wifi_rgb_ );
	
	    }
	
	
	
	    /** METAL *********************************/
	
	    //if (FIRST_METAL){
		//FIRST_METAL = false;
		//metal_ = cv::Mat_<uint8_t>(msg->info.height, msg->info.width,0xFF);
		//metal_center_ = cv::Point3i(-info_.origin.position.x/info_.resolution,
					    //-info_.origin.position.y/info_.resolution,0);
	    //}
	
	
	    //// Some variables to select the useful bounding box
	
	    //ROS_INFO(" metal_info = %f", metal_info);
	
	    //int precision = 1/info_.resolution;
	    //if (metal_info > 0.8){
		//for (unsigned int i = current_position.x - precision; i < current_position.x + precision; i++) {
		    //for (unsigned int j = current_position.y - precision; j < current_position.y + precision; j++) {
			//metal_(j, i) = (BLACK + metal_(j, i))/2;
		    //}
		//}
	
	    //} else if (metal_info > 0.6) {
		//for (unsigned int i = current_position.x - precision; i < current_position.x + precision; i++) {
		    //for (unsigned int j = current_position.y - precision; j < current_position.y + precision; j++) {
			//metal_(j, i) = (DARK_GREY +  metal_(j, i))/2;
		    //}
		//}
	    //} else if (metal_info > 0.4) {
	
		//for (unsigned int i= current_position.x - precision;i<current_position.x + precision ;i++){
		    //for (unsigned int j=current_position.y - precision; j<current_position.y + precision ;j++) {
			//metal_(j,i) = (GREY +  metal_(j,i))/2 ;
		    //}
		//}
	    //} else if (metal_info > 0.2) {
		//for (unsigned int i= current_position.x - precision;i<current_position.x + precision ;i++){
		    //for (unsigned int j=current_position.y - precision; j<current_position.y + precision ;j++) {
			//metal_(j,i) = (LIGHT_GREY + metal_(j,i))/2 ;
		    //}
		//}
		//ROS_INFO("LIGHT_GREY");
	       //} else  {
	
		//for (unsigned int i= current_position.x - precision;i<current_position.x + precision ;i++){
		    //for (unsigned int j=current_position.y - precision; j<current_position.y + precision ;j++) {
			//metal_(j,i) = (WHITE  + metal_(j,i))/2;
		    //}
		//}
	
		//ROS_INFO("WHITE");
	    //}
	
	
	    //if (!ready) {
		//ready = true;
		//ROS_INFO("Received Metal grid, ready to plan");
	    //}
	
	    ////cv::cvtColor(og_, og_rgb_, CV_GRAY2RGB);
	    //cv::cvtColor(metal_, metal_rgb_, CV_GRAY2RGB);
	    //// Compute a sub-image that covers only the useful part of the
	    //// grid.
	    //cropped_metal_ = cv::Mat_<uint8_t>(metal_,roi_);
	    ////cropped_og_ = cv::Mat_<uint8_t>(og_,roi_);
	    //if ((w > WIN_SIZE) || (h > WIN_SIZE)) {
		//// The occupancy grid is too large to display. We need to scale
		//// it first.
		//double ratio = w / ((double)h);
		//cv::Size new_size;
		//if (ratio >= 1) {
		    //new_size = cv::Size(WIN_SIZE,WIN_SIZE/ratio);
		//} else {
		    //new_size = cv::Size(WIN_SIZE*ratio,WIN_SIZE);
		//}
		////cv::Mat_<uint8_t> resized_og;
		////cv::resize(cropped_og_,resized_og,new_size);
		////cv::imshow( "OccGrid", resized_og );
		//cv::Mat_<uint8_t> resized_metal;
		//cv::resize(cropped_metal_,resized_metal,new_size);
		//cv::imshow( "METAL ", resized_metal );
	    //} else {
		//// cv::imshow( "OccGrid", cropped_og_ );
		////cv::imshow( "OccGrid", og_rgb_ );
		//cv::imshow( "METAL ", metal_rgb_ );
	
	    //}
	
	    }
	






    public:
        OccupancyGridPlanner() : nh_("~") {
            int nbour = 5;
            ready = false;
            nh_.param("base_frame",base_link_,std::string("/base_link"));
            nh_.param("debug",debug,false);
            nh_.param("neighbourhood",nbour,nbour);
	    nh_.param("robot_radius_",robot_radius_,0.15);
            switch (nbour) {
		case 3: neighbourhood_ = nbour; break;
                case 4: neighbourhood_ = nbour; break;
		case 5: neighbourhood_ = nbour; break;
                case 8: neighbourhood_ = nbour; break;
                default: 
                    ROS_WARN("Invalid neighbourhood specification (%d instead of 3 or 4 or 5 or 8)",nbour);
                    neighbourhood_ = 8;
            }
            og_sub_   = nh_.subscribe("occ_grid",1,&OccupancyGridPlanner::og_callback,this);
            //target_sub_   = nh_.subscribe("goal_to_pub",1,&OccupancyGridPlanner::target_callback,this);
            path_pub_ = nh_.advertise<nav_msgs::Path>("path",1,true);
	    
	       
	    /* goal pub + vel_pub*/
	    //target_pub_   = nh_.advertise<geometry_msgs::PoseStamped>("goal_to_pub",1,true);	    
	    vel_pub_   = nh_.advertise<geometry_msgs::Twist>("velocity_rot",1,true);	
	    target_pub_   = nh_.advertise<nav_msgs::OccupancyGrid>("goal_to_pub",1,true);
	    wifi_sub_ = nh_.subscribe("wifi",1,&OccupancyGridPlanner::wifi_callback,this);
	    battery_sub_ = nh_.subscribe("battery",1,&OccupancyGridPlanner::battery_callback,this);
	    button_sub_ = nh_.subscribe("button_bot_",1,&OccupancyGridPlanner::button_callback,this);

        }

	

};

/**********************************************/

void state_machine(){

    switch(STATE){
        printf("%d", STATE);
        case 0:

            STATE0 = true;
            STATE1 = false;
            STATE2 = false;
            STATE3 = false;
	    STATE4 = false;
	    STATE5 = false;

            ROS_INFO(" Current state :: State 0 :: Determine Point To Reach");

            if (BATTERY_LOW){
		ROS_INFO(" ---- > BATTERY_LOW");
		BATTERY_LOW = false;
		STATE = 4;
            }
	    else if (BUTTON_PUSH){
		ROS_INFO(" ---- > BUTTON_PUSH");
		BUTTON_PUSH= false;
		STATE = 4;
	    }
            else if (POINT_TO_REACH_DETERMINED){
                ROS_INFO(" ---- > POINT_TO_REACH_DETERMINED");
                POINT_TO_REACH_DETERMINED = false;
                STATE = 1;
            }
            else if (NO_POINT_TO_REACH){
                ROS_INFO(" ---- > NO_POINT_TO_REACH");
                NO_POINT_TO_REACH = false;
                STATE = 3;
            }

            else if(TARGET_UNKNOWN){
                ROS_INFO(" ---- > TARGET_UNKNOWN");
                TARGET_UNKNOWN = false;
                STATE = 2;

            }
            else if(NO_PATH_FOUND){
                ROS_INFO(" ---- > NO_PATH_FOUND");
                NO_PATH_FOUND = false;
                STATE = 2;

             }
            else if(START_UNKNOWN){
                ROS_INFO(" ---- > START_UNKNOWN");
                START_UNKNOWN = false;
                STATE = 2;
            }
            else STATE = 0;
            break;

        case 1:

            STATE0 = false;
            STATE1 = true;
            STATE2 = false;
            STATE3 = false;
	    STATE4 = false;
	    STATE5 = false;

            ROS_INFO(" Current state :: State 1 :: Go to Point To Reach");
	    
	    if (GOAL_REACHED) {
                ROS_INFO(" ---- > GOAL_REACHED");
                GOAL_REACHED = false;
                STATE = 2;
            } else if (BUTTON_PUSH){
			ROS_INFO(" ---- > BUTTON_PUSH");
			BUTTON_PUSH= false;
			STATE = 4;
			}
            else if (TIMEOUT) {
                ROS_INFO(" ---- > TIMEOUT");
                TIMEOUT = false;
                STATE = 2;
            }
            else STATE = 1;
            break;

        case 2:

            STATE0 = false;
            STATE1 = false;
            STATE2 = true;
            STATE3 = false;
	    STATE4 = false;
	    STATE5 = false;

            ROS_INFO(" Current state :: State 2 :: Rotation on itself");
	    
	    if (ROTATION_DONE) {
                ROS_INFO(" ---- > ROTATION_DONE");
                ROTATION_DONE = false;
                STATE = 0;
            } else if (BUTTON_PUSH){
				ROS_INFO(" ---- > BUTTON_PUSH");
				BUTTON_PUSH= false;
				STATE = 4;
			}
            else STATE = 2;
            break;

        case 3:

            STATE0 = false;
            STATE1 = false;
            STATE2 = false;
            STATE3 = true;
	    STATE4 = false;
	    STATE5 = false;
	    
	    ROS_INFO(" Current state :: State 3 :: Finished exploring");
	    
	    if (BUTTON_PUSH){
		ROS_INFO(" ---- > BUTTON_PUSH");
		BUTTON_PUSH= false;
		STATE = 4;
	    }
         
	    else  STATE = 3;
            break;

	case 4:
	    STATE0 = false;
	    STATE1 = false;
	    STATE2 = false;
	    STATE3 = false;
	    STATE4 = true;
	    STATE5 = false;

	    ROS_INFO(" Current state :: State 5 :: THE ROBOT GO TO DOCKER ");

	    if (GO_TO_TRIGERRED) {
		    ROS_INFO(" ---- > GO_TO_TRIGERRED");
		    GO_TO_TRIGERRED = false;
		    STATE = 5;
	    }
	    else STATE = 4;
	    break;

	case 5:
	    STATE0 = false;
	    STATE1 = false;
	    STATE2 = false;
	    STATE3 = false;
	    STATE4 = false;
	    STATE5 = true;

	    ROS_INFO(" Current state :: State 5 :: THE ROBOT GO TO DOCKER ");

	    if (BATTERY_HIGH) {
		    ROS_INFO(" ---- > BATTERY_HIGH");
		    BATTERY_HIGH = false;
		    STATE = 0;
	   }
	   /*else if (BUTTON_PUSH){
		    ROS_INFO(" ---- > BUTTON_PUSH");
		    BUTTON_PUSH= false;
		    STATE = 0;
	    }*/
	    else STATE = 5;
	    break;
    }


}

int main(int argc, char * argv[]) {
    ros::init(argc,argv,"occgrid_planner");
    OccupancyGridPlanner ogp;
    cv::namedWindow( "OccGrid", CV_WINDOW_AUTOSIZE );
    cv::namedWindow( "wifi", CV_WINDOW_AUTOSIZE );
    // Timer is started
    TIME_START = ros::Time::now().toSec();
    while (ros::ok()) {
	ros::spinOnce();
	TIMEOUT = false;

	// The timer is started + The duration from the timer start point and now is upper than 5
	if ( (TIME_START != 0) && ((ros::Time::now().toSec() - TIME_START) > 30.0)) {    //default 5.

	    // The timer is put to 0 (off) ( and it should only start when the robot begins to move)
        //TIME_START = 0;
	    TIMEOUT = true;
	    TIME_START  = ros::Time::now().toSec();
	}

	state_machine();


	if (cv::waitKey( 50 )== 'q') {
            ros::shutdown();
	}

    }
}

